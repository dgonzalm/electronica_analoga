%% rotor3d_motor_pi.m - Electronica Analogica (UNAL) - Clase 9
% Agrega al modelo (con tablero en vivo) un ROTOR 3D en Simscape Multibody que
% gira con la velocidad simulada del motor, en camara lenta, sincronizado con
% la simulacion. Al dar Run se abre el Mechanics Explorer con el rotor girando
% mientras se mueven las perillas del tablero.
tablero_motor_pi;                       % circuito + tablero en vivo
mdl = 'motor_pi_ao';
camara_lenta = 50;                      % el rotor 3D gira 50 veces mas lento que el real
assignin(get_param(mdl,'ModelWorkspace'),'camara_lenta',camara_lenta);
x0 = 1560; y0 = 690;                    % esquina del area 9 (a la derecha del tablero)

%% Angulo del rotor (en camara lenta) a partir de las rpm simuladas
B(mdl,'simulink/Signal Routing/From','From rpm 3D',[x0+20 y0+40],[50 22]);
set_param([mdl '/From rpm 3D'],'GotoTag','rpm','ShowName','off');
B(mdl,'simulink/Math Operations/Gain','rpm a rad por s (camara lenta)',[x0+120 y0+40],[40 30]);
set_param([mdl '/rpm a rad por s (camara lenta)'],'Gain','2*pi/60/camara_lenta');
B(mdl,'simulink/Continuous/Integrator','angulo',[x0+200 y0+40],[30 30]);
B(mdl,'nesl_utility/Simulink-PS Converter','S-PS angulo',[x0+270 y0+40],[30 24]);
set_param([mdl '/S-PS angulo'],'Unit','rad','FilteringAndDerivatives','filter', ...
    'InputFilterTimeConstant','0.005');
try, set_param([mdl '/S-PS angulo'],'SimscapeFilterOrder','2'); catch, end
add_line(mdl,'From rpm 3D/1','rpm a rad por s (camara lenta)/1','autorouting','smart');
add_line(mdl,'rpm a rad por s (camara lenta)/1','angulo/1','autorouting','smart');
add_line(mdl,'angulo/1','S-PS angulo/1','autorouting','smart');

%% Mecanismo 3D
B(mdl,'sm_lib/Frames and Transforms/World Frame','Mundo',[x0+40 y0+180],[40 40]);
B(mdl,sprintf('sm_lib/Utilities/Mechanism\nConfiguration'),'Config mecanismo',[x0+40 y0+260],[40 40]);
B(mdl,'nesl_utility/Solver Configuration','Solver 3D',[x0+40 y0+330],[40 30]);
B(mdl,'sm_lib/Joints/Revolute Joint','Eje del motor (revoluta)',[x0+200 y0+180],[60 60]);
set_param([mdl '/Eje del motor (revoluta)'],'MotionActuationMode','InputMotion', ...
    'TorqueActuationMode','ComputedTorque');
B(mdl,sprintf('sm_lib/Frames and Transforms/Rigid\nTransform'),'Bajar carcasa',[x0+200 y0+300],[40 40]);
set_param([mdl '/Bajar carcasa'],'TranslationMethod','Cartesian', ...
    'TranslationCartesianOffset','[0 0 -0.036]');
B(mdl,'sm_lib/Body Elements/Cylindrical Solid','Carcasa del motor',[x0+320 y0+300],[50 50]);
set_param([mdl '/Carcasa del motor'],'CylinderRadius','0.035','CylinderLength','0.06', ...
    'GraphicDiffuseColor','[0.42 0.43 0.44]');
B(mdl,'sm_lib/Body Elements/Cylindrical Solid','Rotor (disco)',[x0+360 y0+120],[50 50]);
set_param([mdl '/Rotor (disco)'],'CylinderRadius','0.06','CylinderLength','0.008', ...
    'GraphicDiffuseColor','[0.49 0.60 0.24]');
B(mdl,sprintf('sm_lib/Frames and Transforms/Rigid\nTransform'),'Posicion marcador',[x0+360 y0+200],[40 40]);
set_param([mdl '/Posicion marcador'],'TranslationMethod','Cartesian', ...
    'TranslationCartesianOffset','[0.042 0 0.006]');
B(mdl,'sm_lib/Body Elements/Brick Solid','Marcador',[x0+460 y0+200],[50 50]);
set_param([mdl '/Marcador'],'BrickDimensions','[0.026 0.012 0.006]', ...
    'GraphicDiffuseColor','[0.71 0.33 0.24]');
B(mdl,'sm_lib/Body Elements/Cylindrical Solid','Eje',[x0+360 y0+260],[50 50]);
set_param([mdl '/Eje'],'CylinderRadius','0.007','CylinderLength','0.03', ...
    'GraphicDiffuseColor','[0.2 0.2 0.2]');

J = 'Eje del motor (revoluta)';
L(mdl,'Mundo',J,'B');
L(mdl,'Mundo','Config mecanismo');
L(mdl,'Mundo','Solver 3D');
L(mdl,'Mundo','Bajar carcasa','B');
L(mdl,'Bajar carcasa','Carcasa del motor','F');
L(mdl,J,'Rotor (disco)','F');
L(mdl,J,'Posicion marcador','F');
L(mdl,'Posicion marcador','Marcador','F');
L(mdl,J,'Eje','F');
ph = get_param([mdl '/' J],'PortHandles');
pq = get_param([mdl '/S-PS angulo'],'PortHandles');
add_line(mdl,pq.RConn(1),ph.LConn(2),'autorouting','smart');    % angulo -> entrada q

add_block('built-in/Area',[mdl '/9 . Rotor 3D (Simscape Multibody) - gira en camara lenta x50'], ...
    'Position',[x0-20 y0-35 x0+540 y0+380]);

%% Verificacion de conectividad del mecanismo
nc = {};
for b = find_system(mdl,'SearchDepth',1,'Type','Block')'
    pp = get_param(b{1},'PortHandles');
    for t = {'LConn','RConn','Inport','Outport'}
        for k = 1:numel(pp.(t{1}))
            if get_param(pp.(t{1})(k),'Line') == -1
                nc{end+1} = sprintf('%s.%s%d',get_param(b{1},'Name'),t{1},k); %#ok<AGROW>
            end
        end
    end
end
if isempty(nc), disp('Rotor 3D conectado: ningun puerto suelto');
else, fprintf('PUERTOS SUELTOS: %s\n',strjoin(nc,', ')); end
save_system(mdl);
fprintf('Listo. Dale Run: se abre el Mechanics Explorer con el rotor girando en vivo.\n');

%% ===================== funciones auxiliares =====================
function B(mdl,lib,name,ctr,sz)
add_block(lib,[mdl '/' name],'Position',round([ctr-sz/2 ctr+sz/2]));
end
function L(mdl,a,b,lado)
% conecta el puerto de marco de 'a' con el puerto 'lado' (B o F) de 'b'
pa = get_param([mdl '/' a],'PortHandles');
pb = get_param([mdl '/' b],'PortHandles');
if ~isempty(pa.RConn), sa = pa.RConn(1); else, sa = pa.LConn(1); end
if nargin < 4 || strcmp(lado,'B')
    if ~isempty(pb.LConn), sb = pb.LConn(1); else, sb = pb.RConn(1); end
else
    if strcmp(lado,'F') && ~isempty(pb.LConn), sb = pb.LConn(1); else, sb = pb.RConn(1); end
end
add_line(mdl,sa,sb,'autorouting','smart');
end
