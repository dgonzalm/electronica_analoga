%% anim_motor_pi.m - Electronica Analogica (UNAL) - Clase 9
% Simula motor_pi_ao.slx y anima el resultado: rotor girando, tacometro de
% aguja y las senales del lazo (Vref, Vtaco y voltaje del motor).
%
mdl = 'motor_pi_ao';
cambios = struct();
% EXPERIMENTA: quita el % de una linea para cambiar el circuito antes de simular
% (los cambios quedan guardados en el Model Workspace del modelo)
% cambios.Vref   = 11;      % pide mas velocidad de la que el motor puede dar
% cambios.R2     = 300e3;   % Kp = R2/Rin mas grande
% cambios.C2     = 50e-6;   % Ki = 1/(Rin*C2) mas pequeno
% cambios.Tcarga = 10e-3;   % mas carga en el eje
camara_lenta = 50;      % el rotor se dibuja 50 veces mas lento (si no, se ve borroso)
fps = 30;
grabar_video = false;   % true -> guarda motor_pi_animacion.mp4

%% Simular
if ~bdIsLoaded(mdl), load_system(mdl); end
ws = get_param(mdl,'ModelWorkspace');
f = fieldnames(cambios);
for i = 1:numel(f), assignin(ws,f{i},cambios.(f{i})); end
out = sim(mdl);
gv = @(n) out.logsout.get(n).Values;
s_rpm = gv('rpm'); s_vt = gv('Vtaco'); s_vm = gv('Vmotor'); s_vr = gv('Vref');
T  = s_rpm.Time(end);
t  = (0:1/fps:T)';
rs = @(s) interp1(s.Time,double(squeeze(s.Data)),t,'linear','extrap');
rpm = rs(s_rpm); vt = rs(s_vt); vm = rs(s_vm); vr = rs(s_vr);
th_f = cumtrapz(s_rpm.Time,double(squeeze(s_rpm.Data))*2*pi/60);   % angulo real (rad)
th   = interp1(s_rpm.Time,th_f,t);
tc   = getVariable(ws,'t_carga');
Kt   = getVariable(ws,'Kt');
Vsat = getVariable(ws,'Vsat');
Kp   = getVariable(ws,'R2')/getVariable(ws,'Rin');
Ki   = 1/(getVariable(ws,'Rin')*getVariable(ws,'C2'));
rpm_ref = vr/Kt*60/(2*pi);
rmax = 5000;

%% Colores UNAL
verde  = [124 154 62]/255;  verdeC = [162 191 83]/255;  tinte = [242 246 233]/255;
gris   = [106 110 112]/255; grisC  = [218 219 213]/255; rojo  = [181 83 60]/255;

%% Figura
fig = figure('Color','w','Position',[40 40 1280 680], ...
    'Name','Motor DC controlado por un PI con amplificadores operacionales');
annotation(fig,'textbox',[0.02 0.92 0.96 0.07],'String', ...
    sprintf('Control de velocidad de un motor DC con un PI de amplificadores operacionales   (K_p = %.2g,  K_i = %.2g s^{-1},  AO saturan en \\pm%g V)',Kp,Ki,Vsat), ...
    'EdgeColor','none','FontSize',14,'FontWeight','bold','Color',[0.1 0.1 0.1],'FontName','Georgia');

% --- rotor (vista frontal)
axM = axes(fig,'Position',[0.02 0.18 0.30 0.66]); hold(axM,'on'); axis(axM,'equal','off');
axis(axM,[-1.5 1.7 -1.5 1.5]);
c = linspace(0,2*pi,120);
fill(axM,1.25*cos(c),1.25*sin(c),grisC,'EdgeColor',gris,'LineWidth',2);      % carcasa
fill(axM,1.00*cos(c),1.00*sin(c),tinte,'EdgeColor',verde,'LineWidth',2);     % rotor
hS = gobjects(4,1);
for k = 1:4, hS(k) = plot(axM,[0 0],[0 0],'Color',verde,'LineWidth',5); end
hM = plot(axM,0,0,'o','MarkerSize',16,'MarkerFaceColor',rojo,'MarkerEdgeColor','w');
fill(axM,0.15*cos(c),0.15*sin(c),gris,'EdgeColor','none');
hB = fill(axM,[1.30 1.55 1.55 1.30],[-0.35 -0.35 0.35 0.35],grisC,'EdgeColor',gris,'LineWidth',1.5);
hBt = text(axM,1.43,-0.55,'freno','HorizontalAlignment','center','Color',gris,'FontSize',11);
text(axM,0,-1.45,sprintf('rotor en camara lenta (x%d)',camara_lenta), ...
    'HorizontalAlignment','center','Color',gris,'FontSize',10,'FontAngle','italic');

% --- tacometro de aguja
axG = axes(fig,'Position',[0.33 0.40 0.30 0.48]); hold(axG,'on'); axis(axG,'equal','off');
axis(axG,[-1.25 1.25 -0.95 1.25]);
a0 = deg2rad(225); a1 = deg2rad(-45);
ang = @(r) a0 + (a1-a0)*min(max(r,0),rmax)/rmax;
aa = linspace(a0,a1,200);
plot(axG,cos(aa),sin(aa),'Color',gris,'LineWidth',3);
for r = 0:500:rmax
    q = ang(r); L = 0.08 + 0.06*(mod(r,1000)==0);
    plot(axG,[cos(q) (1-L)*cos(q)],[sin(q) (1-L)*sin(q)],'Color',gris,'LineWidth',1.5);
    if mod(r,1000)==0
        text(axG,0.76*cos(q),0.76*sin(q),sprintf('%d',r),'HorizontalAlignment','center', ...
            'FontSize',10,'Color',gris);
    end
end
hR = plot(axG,0,0,'v','MarkerSize',12,'MarkerFaceColor',verdeC,'MarkerEdgeColor',verde);  % referencia
hN = plot(axG,[0 0],[0 0],'Color',rojo,'LineWidth',3.5);
fill(axG,0.07*cos(c),0.07*sin(c),[0.15 0.15 0.15],'EdgeColor','none');
hTxt = text(axG,0,-0.45,'','HorizontalAlignment','center','FontSize',22,'FontWeight','bold', ...
    'FontName','Consolas','Color',[0.1 0.1 0.1]);
text(axG,0,-0.68,'rpm','HorizontalAlignment','center','FontSize',11,'Color',gris);
hEst = text(axG,0,-0.88,'','HorizontalAlignment','center','FontSize',12,'FontWeight','bold');

% --- senales
ax1 = axes(fig,'Position',[0.68 0.56 0.29 0.32]); hold(ax1,'on'); grid(ax1,'on'); box(ax1,'on');
plot(ax1,t,vr,'--','Color',gris,'LineWidth',1.5);
h1 = animatedline(ax1,'Color',verde,'LineWidth',2.2);
xlim(ax1,[0 T]); ylim(ax1,[-0.5 max([vr;vt])*1.25+0.5]);
ylabel(ax1,'voltios'); title(ax1,'Referencia V_{ref} (gris) y tacometro V_{taco} (verde)','FontWeight','normal');
xline(ax1,tc,':','carga','Color',rojo,'LabelVerticalAlignment','bottom');
ax2 = axes(fig,'Position',[0.68 0.12 0.29 0.32]); hold(ax2,'on'); grid(ax2,'on'); box(ax2,'on');
h2 = animatedline(ax2,'Color',rojo,'LineWidth',2.2);
yline(ax2,Vsat,'--','saturacion del AO','Color',gris,'LabelHorizontalAlignment','left');
xlim(ax2,[0 T]); ylim(ax2,[-1 Vsat+2]);
xlabel(ax2,'tiempo (s)'); ylabel(ax2,'voltios');
title(ax2,'Voltaje que el PI le entrega al motor','FontWeight','normal');
xline(ax2,tc,':','carga','Color',rojo,'LabelVerticalAlignment','bottom');

hT = annotation(fig,'textbox',[0.36 0.12 0.26 0.16],'String','','EdgeColor',grisC, ...
    'BackgroundColor',tinte,'FontSize',12,'FontName','Consolas','VerticalAlignment','middle');

%% Animar
if grabar_video
    try, vw = VideoWriter('motor_pi_animacion','MPEG-4');
    catch, vw = VideoWriter('motor_pi_animacion','Motion JPEG AVI'); end
    vw.FrameRate = fps; open(vw);
end
for k = 1:numel(t)
    a = th(k)/camara_lenta;
    for s = 1:4
        q = a + (s-1)*pi/2;
        set(hS(s),'XData',[0 0.95*cos(q)],'YData',[0 0.95*sin(q)]);
    end
    set(hM,'XData',0.78*cos(a+pi/4),'YData',0.78*sin(a+pi/4));
    q = ang(rpm(k)); set(hN,'XData',[0 0.88*cos(q)],'YData',[0 0.88*sin(q)]);
    q = ang(rpm_ref(k)); set(hR,'XData',1.08*cos(q),'YData',1.08*sin(q));
    hTxt.String = sprintf('%4.0f',rpm(k));
    if t(k) >= tc
        set(hB,'XData',[1.02 1.27 1.27 1.02],'FaceColor',rojo); hBt.Color = rojo;
        hBt.String = 'carga aplicada';
    end
    err = rpm_ref(k) - rpm(k);
    if vm(k) >= 0.98*Vsat
        hEst.String = 'AO saturado: no da mas voltaje'; hEst.Color = rojo;
    elseif abs(err) < 0.02*max(rpm_ref(k),1) && rpm_ref(k) > 0
        hEst.String = 'en la referencia'; hEst.Color = verde;
    elseif rpm_ref(k) > 0
        hEst.String = 'corrigiendo el error...'; hEst.Color = gris;
    else
        hEst.String = 'esperando referencia'; hEst.Color = gris;
    end
    addpoints(h1,t(k),vt(k)); addpoints(h2,t(k),vm(k));
    hT.String = sprintf(' t       = %5.2f s\n Vref    = %5.2f V\n Vtaco   = %5.2f V\n Vmotor  = %5.2f V', ...
        t(k),vr(k),vt(k),vm(k));
    drawnow;
    if grabar_video, writeVideo(vw,getframe(fig)); else, pause(1/fps); end
end
if grabar_video, close(vw); fprintf('Video guardado: %s\n',vw.Filename); end
