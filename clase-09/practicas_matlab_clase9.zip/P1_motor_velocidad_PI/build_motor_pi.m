%% build_motor_pi.m - Electronica Analogica (UNAL) - Clase 9
% Control de velocidad de un motor DC con un controlador PI implementado con
% amplificadores operacionales reales (ganancia finita, saturacion +-12 V),
% simulado en Simscape Electrical. Ejecutar este script reconstruye el modelo.
%
% Cadena:  Vref -> AO1 (PI compacto sumador) -> AO2 (inversor) -> etapa de
%          potencia (x1) -> motor DC + carga -> tacometro (invertido) -> AO1
clear P L f ws nc b i ty hh k
mdl = 'motor_pi_ao';
if bdIsLoaded(mdl), close_system(mdl,0); end
new_system(mdl);

%% Parametros (quedan en el Model Workspace: se cambian ahi o con set_param)
P.Vref    = 5;       % V    referencia de velocidad (5 V <-> 250 rad/s)
P.t_ref   = 0.5;     % s    instante del escalon de referencia
P.Tcarga  = 5e-3;    % N*m  par de carga que se aplica de golpe
P.t_carga = 3;       % s    instante en que entra la carga
P.Rin     = 100e3;   % ohm  resistencias de entrada del PI (Vref y taco)
P.R2      = 100e3;   % ohm  realimentacion del PI   -> Kp = R2/Rin = 1
P.C2      = 5e-6;    % F    realimentacion del PI   -> Ki = 1/(Rin*C2) = 2 1/s
P.Rinv    = 10e3;    % ohm  inversor unitario
P.Vsat    = 12;      % V    saturacion de los AO (alimentacion +-12 V)
P.Aol     = 1e5;     %      ganancia de lazo abierto de los AO
P.Ra      = 2;       % ohm  resistencia de armadura
P.La      = 1e-3;    % H    inductancia de armadura
P.Km      = 0.02;    % V/(rad/s) constante del motor
P.Jm      = 5e-5;    % kg*m^2 inercia del rotor
P.Jc      = 5e-5;    % kg*m^2 inercia de la carga acoplada
P.Bf      = 1e-5;    % N*m/(rad/s) friccion viscosa
P.Kt      = 0.02;    % V/(rad/s) tacometro (10 V a 500 rad/s)
ws = get_param(mdl,'ModelWorkspace');
f = fieldnames(P);
for i = 1:numel(f), assignin(ws,f{i},P.(f{i})); end

%% Librerias
L.R    = 'fl_lib/Electrical/Electrical Elements/Resistor';
L.C    = 'fl_lib/Electrical/Electrical Elements/Capacitor';
L.GND  = 'fl_lib/Electrical/Electrical Elements/Electrical Reference';
L.AO   = 'ee_lib/Integrated Circuits/Finite-Gain Op-Amp';
L.CVS  = sprintf('fl_lib/Electrical/Electrical Sources/Controlled Voltage\nSource');
L.VCVS = sprintf('fl_lib/Electrical/Electrical Sources/Voltage-Controlled\nVoltage Source');
L.VS   = 'fl_lib/Electrical/Electrical Sensors/Voltage Sensor';
L.MOT  = 'ee_lib/Electromechanical/Brushed Motors/DC Motor';
L.J    = 'fl_lib/Mechanical/Rotational Elements/Inertia';
L.B    = 'fl_lib/Mechanical/Rotational Elements/Rotational Damper';
L.MREF = sprintf('fl_lib/Mechanical/Rotational Elements/Mechanical\nRotational Reference');
L.TS   = 'fl_lib/Mechanical/Mechanical Sources/Ideal Torque Source';
L.MS   = sprintf('fl_lib/Mechanical/Mechanical Sensors/Ideal Rotational\nMotion Sensor');
L.SPS  = 'nesl_utility/Simulink-PS Converter';
L.PSS  = 'nesl_utility/PS-Simulink Converter';
L.SOL  = 'nesl_utility/Solver Configuration';
L.PSG  = 'fl_lib/Physical Signals/Functions/PS Gain';

%% 1 - Referencia
addb(mdl,'simulink/Sources/Step','Vref',[70 430],[30 30]);
sp(mdl,'Vref','Time','t_ref'); sp(mdl,'Vref','Before','0'); sp(mdl,'Vref','After','Vref');
addb(mdl,L.SPS,'S-PS ref',[140 430],[30 24]); sp(mdl,'S-PS ref','Unit','V');
gto(mdl,'Goto Vref','Vref',[125 380]);
addb(mdl,L.CVS,'Fuente Vref',[230 360],[40 60]);
placeAt(mdl,'Fuente Vref','LConn',1,[230 340]);
gnd(mdl,'GND1',pt(mdl,'Fuente Vref','RConn',2)+[0 32]);
addb(mdl,L.SOL,'Solver',[150 470],[40 30]);
placeAt(mdl,'Solver','RConn',1,pt(mdl,'Fuente Vref','LConn',1)+[-45 -25]);

%% 2 - AO1: PI compacto sumador  Vo1 = -(Kp + Ki/s)(Vref - Vtaco)
addb(mdl,L.AO,'AO1',[520 300],[60 60]); flipAO(mdl,'AO1'); aoPar(mdl,'AO1');
placeAt(mdl,'AO1','LConn',2,[486 285]);                 % entrada (-) arriba
addb(mdl,L.R,'Rin1 = 100k',[388 285],[60 20]); sp(mdl,'Rin1 = 100k','R','Rin');
placeAt(mdl,'Rin1 = 100k','RConn',1,[420 285]);
addb(mdl,L.R,'Rin2 = 100k',[450 370],[20 60],'Orientation','down'); sp(mdl,'Rin2 = 100k','R','Rin');
placeTop(mdl,'Rin2 = 100k',[450 335]);
gnd(mdl,'GND2',[474 352]);
addb(mdl,L.R,'R2 = 100k',[515 220],[60 20]); sp(mdl,'R2 = 100k','R','R2');
addb(mdl,L.C,'C2 = 5u',[600 220],[60 20]); sp(mdl,'C2 = 5u','c','C2');

%% 3 - AO2: inversor unitario  Vo2 = -Vo1
addb(mdl,L.AO,'AO2',[800 315],[60 60]); flipAO(mdl,'AO2'); aoPar(mdl,'AO2');
placeAt(mdl,'AO2','LConn',2,[766 300]);
addb(mdl,L.R,'R3 = 10k',[700 300],[60 20]); sp(mdl,'R3 = 10k','R','Rinv');
placeAt(mdl,'R3 = 10k','RConn',1,[736 300]);
addb(mdl,L.R,'R4 = 10k',[800 235],[60 20]); sp(mdl,'R4 = 10k','R','Rinv');
gnd(mdl,'GND3',[754 367]);

%% 4 - Etapa de potencia (seguidor de corriente, ganancia 1)
addb(mdl,L.VCVS,'Etapa de potencia x1',[915 370],[50 60]); sp(mdl,'Etapa de potencia x1','K','1');
placeAt(mdl,'Etapa de potencia x1','LConn',1,[900 340]);
gnd(mdl,'GND4',mean([pt(mdl,'Etapa de potencia x1','RConn',1); pt(mdl,'Etapa de potencia x1','RConn',2)])+[0 32]);
addb(mdl,L.VS,'Voltimetro',[990 420],[30 50],'Orientation','down');
placeTop(mdl,'Voltimetro',[990 385]);

%% 5 - Motor DC + carga mecanica
addb(mdl,L.MOT,'Motor DC',[1195 375],[60 70]);
placeAt(mdl,'Motor DC','LConn',1,[1180 340]);
sp(mdl,'Motor DC','Ra','Ra'); sp(mdl,'Motor DC','La','La'); sp(mdl,'Motor DC','La_unit','H');
sp(mdl,'Motor DC','Kv','Km'); sp(mdl,'Motor DC','Kv_unit','V/(rad/s)');
sp(mdl,'Motor DC','J','Jm'); sp(mdl,'Motor DC','J_unit','kg*m^2');
sp(mdl,'Motor DC','lam','0'); sp(mdl,'Motor DC','speed0','0');
gnd(mdl,'GND5',pt(mdl,'Motor DC','RConn',1)+[0 32]);
mref(mdl,'Ref mec 1',pt(mdl,'Motor DC','RConn',2)+[0 32]);
addb(mdl,L.J,'Inercia carga',[1170 365],[40 40]); sp(mdl,'Inercia carga','inertia','Jc');
placeAt(mdl,'Inercia carga','LConn',1,[1290 340]);
addb(mdl,L.B,'Friccion',[1250 370],[30 50],'Orientation','down'); sp(mdl,'Friccion','D','Bf');
placeTop(mdl,'Friccion',[1370 340]);
mref(mdl,'Ref mec 2',botPort(mdl,'Friccion')+[0 32]);
addb(mdl,L.TS,'Par de carga',[1340 370],[50 60]);
placeAt(mdl,'Par de carga','LConn',1,[1460 340]);
mref(mdl,'Ref mec 3',pt(mdl,'Par de carga','RConn',2)+[0 32]);
addb(mdl,'simulink/Sources/Step','Carga',[1335 500],[30 30]);
sp(mdl,'Carga','Time','t_carga'); sp(mdl,'Carga','Before','0'); sp(mdl,'Carga','After','-Tcarga');
addb(mdl,L.SPS,'S-PS carga',[1400 500],[30 24]); sp(mdl,'S-PS carga','Unit','N*m');

%% 6 - Tacometro (sensor de velocidad, conectado invertido -> entrega -Vtaco)
addb(mdl,L.MS,'Sensor de velocidad',[1460 330],[60 60]);
placeAt(mdl,'Sensor de velocidad','LConn',1,[1550 320]);
sp(mdl,'Sensor de velocidad','position_port','false');
cS = pt(mdl,'Sensor de velocidad','RConn',1);     % C (referencia, arriba)
wS = pt(mdl,'Sensor de velocidad','RConn',2);     % W (velocidad)
mref(mdl,'Ref mec 4',cS+[45 -30]);
addb(mdl,L.PSG,'Kt',[1560 330],[40 30]); sp(mdl,'Kt','gain','Kt'); sp(mdl,'Kt','gain_unit','V*s/rad');
placeAt(mdl,'Kt','LConn',1,wS+[60 0]);
kO = pt(mdl,'Kt','RConn',1);
addb(mdl,L.CVS,'Tacometro (invertido)',[1660 420],[40 60]);
placeAt(mdl,'Tacometro (invertido)','RConn',1,kO+[100 110]);
gnd(mdl,'GND6',pt(mdl,'Tacometro (invertido)','LConn',1)+[50 45]);

%% 7 - Medicion (todo llega al osciloscopio con etiquetas Goto/From)
addb(mdl,L.PSS,'Vtaco',[1700 330],[36 24]); sp(mdl,'Vtaco','Unit','V');
placeAt(mdl,'Vtaco','LConn',1,kO+[190 0]);
gto(mdl,'Goto Vtaco','Vtaco',pt(mdl,'Vtaco','Outport',1)+[45 0]);
addb(mdl,L.PSS,'rpm',[1560 400],[36 24]); sp(mdl,'rpm','Unit','rpm');
placeAt(mdl,'rpm','LConn',1,wS+[60 55]);
gto(mdl,'Goto rpm','rpm',pt(mdl,'rpm','Outport',1)+[30 0]);
addb(mdl,L.PSS,'Vmotor',[1010 520],[36 24]); sp(mdl,'Vmotor','Unit','V');
gto(mdl,'Goto Vmotor','Vmotor',[1060 520]);
fro(mdl,'From Vref','Vref',[2240 170]);
fro(mdl,'From Vtaco','Vtaco',[2240 215]);
fro(mdl,'From Vmotor','Vmotor',[2240 275]);
fro(mdl,'From rpm','rpm',[2240 335]);
addb(mdl,'simulink/Signal Routing/Mux','Mux',[2315 192],[6 50]); sp(mdl,'Mux','Inputs','2'); sp(mdl,'Mux','ShowName','off');
addb(mdl,'simulink/Sinks/Scope','Osciloscopio',[2400 255],[40 150]); sp(mdl,'Osciloscopio','NumInputPorts','3');

%% Cableado
% 1 - referencia
W(mdl,{'Vref','Outport',1},{'S-PS ref','Inport',1});
W(mdl,{'Vref','Outport',1},{'Goto Vref','Inport',1});
W(mdl,{'S-PS ref','RConn',1},{'Fuente Vref','RConn',1});
W(mdl,{'Fuente Vref','RConn',2},{'GND1','LConn',1});
W(mdl,{'Solver','RConn',1},{'Fuente Vref','LConn',1});
W(mdl,{'Fuente Vref','LConn',1},{'Rin1 = 100k','LConn',1});
% 2 - AO1
W(mdl,{'Rin1 = 100k','RConn',1},{'AO1','LConn',2});
W(mdl,{'Rin2 = 100k',topName(mdl,'Rin2 = 100k'),1},{'AO1','LConn',2});
W(mdl,{'AO1','LConn',1},{'GND2','LConn',1});
W(mdl,{'AO1','LConn',2},{'R2 = 100k','LConn',1});
W(mdl,{'R2 = 100k','RConn',1},{'C2 = 5u','LConn',1});
W(mdl,{'C2 = 5u','RConn',1},{'AO1','RConn',1});
% 3 - AO2
W(mdl,{'AO1','RConn',1},{'R3 = 10k','LConn',1});
W(mdl,{'R3 = 10k','RConn',1},{'AO2','LConn',2});
W(mdl,{'AO2','LConn',2},{'R4 = 10k','LConn',1});
W(mdl,{'R4 = 10k','RConn',1},{'AO2','RConn',1});
W(mdl,{'AO2','LConn',1},{'GND3','LConn',1});
% 4 - etapa de potencia
W(mdl,{'AO2','RConn',1},{'Etapa de potencia x1','LConn',1});
W(mdl,{'Etapa de potencia x1','RConn',1},{'GND4','LConn',1});
W(mdl,{'Etapa de potencia x1','RConn',2},{'GND4','LConn',1});
W(mdl,{'Etapa de potencia x1','LConn',2},{'Motor DC','LConn',1});
W(mdl,{'Voltimetro','LConn',1},{'Motor DC','LConn',1});
W(mdl,{'Voltimetro','RConn',2},{'GND5','LConn',1});
W(mdl,{'Voltimetro','RConn',1},{'Vmotor','LConn',1});
W(mdl,{'Vmotor','Outport',1},{'Goto Vmotor','Inport',1});
% 5 - motor y carga (eje)
W(mdl,{'Motor DC','RConn',1},{'GND5','LConn',1});
W(mdl,{'Motor DC','RConn',2},{'Ref mec 1','LConn',1});
W(mdl,{'Motor DC','LConn',2},{'Inercia carga','LConn',1});
W(mdl,{'Inercia carga','LConn',1},{'Friccion',topName(mdl,'Friccion'),1});
W(mdl,{'Friccion',botName(mdl,'Friccion'),1},{'Ref mec 2','LConn',1});
W(mdl,{'Friccion',topName(mdl,'Friccion'),1},{'Par de carga','LConn',1});
W(mdl,{'Par de carga','RConn',2},{'Ref mec 3','LConn',1});
W(mdl,{'Carga','Outport',1},{'S-PS carga','Inport',1});
W(mdl,{'S-PS carga','RConn',1},{'Par de carga','RConn',1});
W(mdl,{'Par de carga','LConn',1},{'Sensor de velocidad','LConn',1});
% 6 - tacometro
W(mdl,{'Sensor de velocidad','RConn',1},{'Ref mec 4','LConn',1});
W(mdl,{'Sensor de velocidad','RConn',2},{'Kt','LConn',1});
W(mdl,{'Kt','RConn',1},{'Tacometro (invertido)','RConn',1});
W(mdl,{'Tacometro (invertido)','LConn',1},{'GND6','LConn',1});
W(mdl,{'Tacometro (invertido)','RConn',2},{'Rin2 = 100k',botName(mdl,'Rin2 = 100k'),1});
% 7 - medicion
W(mdl,{'Kt','RConn',1},{'Vtaco','LConn',1});
W(mdl,{'Vtaco','Outport',1},{'Goto Vtaco','Inport',1});
W(mdl,{'Sensor de velocidad','RConn',2},{'rpm','LConn',1});
W(mdl,{'rpm','Outport',1},{'Goto rpm','Inport',1});
W(mdl,{'From Vref','Outport',1},{'Mux','Inport',1});
W(mdl,{'From Vtaco','Outport',1},{'Mux','Inport',2});
W(mdl,{'Mux','Outport',1},{'Osciloscopio','Inport',1});
W(mdl,{'From Vmotor','Outport',1},{'Osciloscopio','Inport',2});
W(mdl,{'From rpm','Outport',1},{'Osciloscopio','Inport',3});
logsig(mdl,'Vtaco','Vtaco'); logsig(mdl,'rpm','rpm');
logsig(mdl,'Vmotor','Vmotor'); logsig(mdl,'Vref','Vref');

%% Configuracion de simulacion
set_param(mdl,'StopTime','6','Solver','ode23t','MaxStep','1e-3', ...
    'SignalLogging','on','SignalLoggingName','logsout','ReturnWorkspaceOutputs','on');

%% Areas rotuladas (estilo libro)
area(mdl,'1 . Referencia',{'Vref','S-PS ref','Goto Vref','Fuente Vref','GND1','Solver'});
area(mdl,'2 . Controlador PI (AO1)',{'AO1','Rin1 = 100k','Rin2 = 100k','GND2','R2 = 100k','C2 = 5u'});
area(mdl,'3 . Inversor (AO2)',{'AO2','R3 = 10k','R4 = 10k','GND3'});
area(mdl,'4 . Potencia',{'Etapa de potencia x1','GND4','Voltimetro','Vmotor','Goto Vmotor'});
area(mdl,'5 . Motor DC + carga',{'Motor DC','GND5','Ref mec 1','Inercia carga','Friccion','Ref mec 2','Par de carga','Ref mec 3','Carga','S-PS carga'});
area(mdl,'6 . Tacometro',{'Sensor de velocidad','Ref mec 4','Kt','Tacometro (invertido)','GND6','Vtaco','Goto Vtaco','rpm','Goto rpm'});
area(mdl,'7 . Osciloscopio',{'From Vref','From Vtaco','From Vmotor','From rpm','Mux','Osciloscopio'});

%% Verificacion de conectividad
nc = {};
b = find_system(mdl,'SearchDepth',1,'Type','Block');
for i = 2:numel(b)
    pp = get_param(b{i},'PortHandles');
    for ty = {'LConn','RConn','Inport','Outport'}
        hh = pp.(ty{1});
        for k = 1:numel(hh)
            if get_param(hh(k),'Line') == -1
                nc{end+1} = sprintf('%s.%s%d',get_param(b{i},'Name'),ty{1},k); %#ok<SAGROW>
            end
        end
    end
end
if isempty(nc), disp('Conectividad OK: ningun puerto suelto');
else, fprintf('PUERTOS SUELTOS: %s\n',strjoin(nc,', ')); end

carpeta = fileparts(mfilename('fullpath'));
save_system(mdl,fullfile(carpeta,[mdl '.slx']));
fprintf('Modelo guardado en %s\n',fullfile(carpeta,[mdl '.slx']));

%% ===================== funciones auxiliares =====================
function p = addb(mdl,lib,name,ctr,sz,varargin)
p = [mdl '/' name];
add_block(lib,p,'Position',round([ctr-sz/2 ctr+sz/2]),varargin{:});
end
function sp(mdl,name,par,val)
p = [mdl '/' name];
try, set_param(p,par,val);
catch e, fprintf('AVISO %s.%s: %s\n',name,par,e.message); end
end
function q = pt(mdl,name,ty,k)
ph = get_param([mdl '/' name],'PortHandles'); q = get_param(ph.(ty)(k),'Position');
end
function h = ph(mdl,name,ty,k)
x = get_param([mdl '/' name],'PortHandles'); h = x.(ty)(k);
end
function placeAt(mdl,name,ty,k,xy)
p = [mdl '/' name]; pos = get_param(p,'Position');
d = round(xy - pt(mdl,name,ty,k)); set_param(p,'Position',pos+[d d]);
end
function t = topName(mdl,name)
if pt(mdl,name,'LConn',1)*[0;1] <= pt(mdl,name,'RConn',1)*[0;1], t = 'LConn'; else, t = 'RConn'; end
end
function t = botName(mdl,name)
if strcmp(topName(mdl,name),'LConn'), t = 'RConn'; else, t = 'LConn'; end
end
function q = botPort(mdl,name)
q = pt(mdl,name,botName(mdl,name),1);
end
function placeTop(mdl,name,xy)
placeAt(mdl,name,topName(mdl,name),1,xy);
end
function flipAO(mdl,name)
p = [mdl '/' name]; set_param(p,'BlockRotation',180); set_param(p,'BlockMirror','on');
end
function aoPar(mdl,name)
sp(mdl,name,'A','Aol'); sp(mdl,name,'Rin','10e6'); sp(mdl,name,'Rout','1');
sp(mdl,name,'Vmin','-Vsat'); sp(mdl,name,'Vmax','Vsat');
end
function gnd(mdl,name,xy)
addb(mdl,'fl_lib/Electrical/Electrical Elements/Electrical Reference',name,xy+[0 15],[24 24]);
set_param([mdl '/' name],'ShowName','off'); placeAt(mdl,name,'LConn',1,xy);
end
function mref(mdl,name,xy)
addb(mdl,sprintf('fl_lib/Mechanical/Rotational Elements/Mechanical\nRotational Reference'),name,xy+[0 15],[24 24]);
set_param([mdl '/' name],'ShowName','off'); placeAt(mdl,name,'LConn',1,xy);
end
function gto(mdl,name,tag,xy)
addb(mdl,'simulink/Signal Routing/Goto',name,xy+[25 0],[50 22]);
set_param([mdl '/' name],'GotoTag',tag,'ShowName','off');
placeAt(mdl,name,'Inport',1,xy);
end
function fro(mdl,name,tag,xy)
addb(mdl,'simulink/Signal Routing/From',name,xy,[50 22]);
set_param([mdl '/' name],'GotoTag',tag,'ShowName','off');
end
function h = W(mdl,a,b)
h = add_line(mdl,ph(mdl,a{:}),ph(mdl,b{:}),'autorouting','smart');
end
function logsig(mdl,name,sig)
if isempty(sig), return; end
x = get_param([mdl '/' name],'PortHandles');
if isempty(x.Outport), return; end
set_param(x.Outport(1),'DataLogging','on','DataLoggingNameMode','Custom','DataLoggingName',sig);
l = get_param(x.Outport(1),'Line'); if l ~= -1, set_param(l,'Name',sig); end
end
function area(mdl,titulo,names)
bb = [inf inf -inf -inf];
for i = 1:numel(names)
    p = get_param([mdl '/' names{i}],'Position');
    bb = [min(bb(1),p(1)) min(bb(2),p(2)) max(bb(3),p(3)) max(bb(4),p(4))];
end
bb = bb + [-20 -40 20 22];
add_block('built-in/Area',[mdl '/' titulo],'Position',round(bb));
end
