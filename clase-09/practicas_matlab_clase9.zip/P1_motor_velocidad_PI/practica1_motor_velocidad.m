%% practica1_motor_velocidad.m - Electronica Analogica (UNAL) - Clase 9
% PRACTICA 1 - Control de VELOCIDAD de un motor DC con un PI hecho con AO.
% Construye el modelo completo:
%   circuito (build_motor_pi) + tablero en vivo (tablero_motor_pi)
%   + rotor 3D Multibody (rotor3d_motor_pi) + osciloscopios en el lienzo.
% Abrir motor_pi_ao.slx, dar Run y mover las perillas mientras simula.
rotor3d_motor_pi;
mdl = 'motor_pi_ao';
U = ea_lib();
y0 = 1080;                                   % fila de osciloscopios

%% La perturbacion (par de carga) tambien va a un Goto
set_param([mdl '/Carga'],'SampleTime','0.01');     % muestreada (el osciloscopio la puede seguir)
U.gto(mdl,'Goto Carga','Carga',U.pt(mdl,'Carga','Outport',1)+[30 -40]);
add_line(mdl,U.ph(mdl,'Carga','Outport',1),U.ph(mdl,'Goto Carga','Inport',1),'autorouting','smart');

%% Sondas (bloques no virtuales registrados: el osciloscopio del lienzo las dibuja)
k = '60/(2*pi*Kt)';                          % voltios del tacometro -> rpm
U.probe(mdl,'s_ref','Vref',k,[60 y0+300],'Referencia (rpm)');
U.probe(mdl,'s_med','Vtaco',k,[60 y0+340],'Velocidad medida (rpm)');
U.probe(mdl,'s_pert','Carga','-1000',[60 y0+380],'Par de carga (mN.m)');
U.probe(mdl,'s_u','Vmotor','1',[60 y0+420],'Esfuerzo de control u (V)');

%% Osciloscopios en el lienzo
U.dscope(mdl,'Referencia vs velocidad medida (rpm)',[60 y0 560 y0+240],{'s_ref','s_med'},15,[0 6000]);
U.dscope(mdl,'Perturbacion: par de carga (mN.m)',[600 y0 1000 y0+240],{'s_pert'},15,[-2 16]);
U.dscope(mdl,'Esfuerzo de control: voltaje al motor u (V)',[1040 y0 1480 y0+240],{'s_u'},15,[-13 13]);
U.areaBox(mdl,'10 . Osciloscopios en vivo',[30 y0-45 1510 y0+460]);

set_param(mdl,'StopTime','inf');             % corre hasta que se presione Stop
U.check(mdl);
save_system(mdl);
fprintf('Practica 1 lista: abre motor_pi_ao.slx y dale Run.\n');
