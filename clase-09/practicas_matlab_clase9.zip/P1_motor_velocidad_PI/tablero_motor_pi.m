%% tablero_motor_pi.m - Electronica Analogica (UNAL) - Clase 9
% Reconstruye motor_pi_ao.slx y le agrega un TABLERO EN VIVO (bloques Dashboard):
% la simulacion corre a ritmo de tiempo real y mientras corre se puede girar
% la perilla de referencia, mover la carga del eje o cambiar R2 (Kp), viendo
% en los medidores como responde el lazo hecho con amplificadores operacionales.
build_motor_pi;                       % modelo limpio
mdl = 'motor_pi_ao';
H  = 'simulink_hmi_blocks/';
y0 = 720;                             % fila del tablero (debajo del circuito)

%% Senales auxiliares para el tablero
add_block('simulink/Signal Routing/From',[mdl '/From Vmotor 2'],'Position',[1250 y0+250 1300 y0+272], ...
    'GotoTag','Vmotor','ShowName','off');
add_block('simulink/Logic and Bit Operations/Compare To Constant',[mdl '/AO saturado?'], ...
    'Position',[1340 y0+243 1400 y0+279],'relop','>=','const','0.98*Vsat');
add_line(mdl,'From Vmotor 2/1','AO saturado?/1','autorouting','smart');
add_block('simulink/Sinks/Terminator',[mdl '/Term sat'],'Position',[1440 y0+251 1460 y0+271],'ShowName','off');
add_line(mdl,'AO saturado?/1','Term sat/1');

%% Los conversores Simulink->PS filtran su entrada (los controles cambian en escalon)
for c = {'S-PS ref','S-PS carga'}
    set_param([mdl '/' c{1}],'FilteringAndDerivatives','filter','InputFilterTimeConstant','0.01');
end

%% Controles (lo que el estudiante mueve)
k1 = hmi(mdl,[H 'Knob'],'Referencia Vref (V)',[60 y0 260 y0+200]);
set_param(k1,'Limits',[0 11]);
replace_block(mdl,'Name','Vref','built-in/Constant','noprompt');   % en vivo: fuente constante que mueve la perilla
set_param([mdl '/Vref'],'Value','5','SampleTime','0.01');   % observable por el tablero
bindParam(k1,[mdl '/Vref'],'Value');

s1 = hmi(mdl,[H 'Slider'],'Carga en el eje (N.m)  <- mas freno',[300 y0+60 560 y0+140]);
set_param(s1,'Limits',[-0.015 0]);
replace_block(mdl,'Name','Carga','built-in/Constant','noprompt');  % arranca sin carga: el estudiante la aplica
set_param([mdl '/Carga'],'Value','0');
bindParam(s1,[mdl '/Carga'],'Value');

k2 = hmi(mdl,[H 'Knob'],'R2 del PI en ohm (Kp = R2 sobre 100k)',[600 y0 800 y0+200]);
set_param(k2,'Limits',[10e3 500e3]);
set_param([mdl '/R2 = 100k'],'R','100e3','R_conf','runtime');
bindParam(k2,[mdl '/R2 = 100k'],'R');

%% Indicadores (lo que el estudiante observa)
g1 = hmi(mdl,[H 'Gauge'],'Velocidad del motor (rpm)',[860 y0 1080 y0+220]);
set_param(g1,'Limits',[0 5000]);
bindSig(g1,[mdl '/rpm'],1);

g2 = hmi(mdl,[H 'Half Gauge'],'Voltaje al motor (V)',[1120 y0 1320 y0+120]);
set_param(g2,'Limits',[0 12]);
bindSig(g2,[mdl '/Vmotor'],1);

l1 = hmi(mdl,[H 'Lamp'],'AO saturado',[1360 y0+30 1440 y0+110]);
bindSig(l1,[mdl '/AO saturado?'],1);
set_param(l1,'StateColors',struct('Value',{0,1},'Color',{[0.82 0.82 0.80],[0.85 0.20 0.15]}));

% (el Dashboard Scope no se usa: en MATLAB Online deja de refrescar tras la primera
%  ventana de tiempo; para ver las curvas en vivo se abre el Osciloscopio del area 7)

add_block('built-in/Area',[mdl '/8 . Tablero en vivo - mueve las perillas mientras simula'], ...
    'Position',[30 y0-45 1490 y0+300]);

%% Simulacion a ritmo de tiempo real
set_param(mdl,'StopTime','60','EnablePacing','on','PacingRate',1);
carpeta = fileparts(mfilename('fullpath'));
save_system(mdl,fullfile(carpeta,[mdl '.slx']));
fprintf('Tablero agregado. Abre el modelo, dale Run y mueve las perillas.\n');
open_system(mdl);

%% ===================== funciones auxiliares =====================
function b = hmi(mdl,lib,name,pos)
b = [mdl '/' name];
add_block(lib,b,'Position',pos);
try, set_param(b,'LabelPosition','Top'); catch, end
end
function bindParam(b,blk,par)
p = Simulink.HMI.ParamSourceInfo;
p.BlockPath = Simulink.BlockPath(blk);
p.ParamName = par;
set_param(b,'Binding',p);
end
function bindSig(b,blk,port)
if ischar(blk), blk = {blk}; end
for i = 1:numel(blk)
    s(i) = Simulink.HMI.SignalSpecification; %#ok<AGROW>
    if port(i) == 0
        % la senal de un Goto se toma del bloque que lo alimenta
        ph = get_param(blk{i},'PortHandles');
        src = get_param(get_param(ph.Inport(1),'Line'),'SrcBlockHandle');
        s(i).BlockPath = Simulink.BlockPath(getfullname(src));
        s(i).OutputPortIndex = 1;
    else
        s(i).BlockPath = Simulink.BlockPath(blk{i});
        s(i).OutputPortIndex = port(i);
    end
end
try
    set_param(b,'Binding',s);
catch
    set_param(b,'Binding',num2cell(s));   % el Dashboard Scope pide lista
end
end
