%% practica4_motor_posicion_pd.m - Electronica Analogica (UNAL) - Clase 9
% PRACTICA 4 - Control de POSICION de un motor DC (un servo) con un PD hecho con AO.
%   Motor DC + caja reductora 20:1 + brazo; un potenciometro de 270 grados mide el
%   angulo del brazo (0..10 V). Con solo P el brazo se pasa y oscila; la rama
%   derivativa (Rd-Cd) lo frena. Con carga en el brazo queda un error que el PD
%   no corrige: ahi se ve para que sirve la accion integral.
%   Tablero en vivo + osciloscopios en el lienzo + brazo 3D con aguja de referencia.
U = ea_lib();
mdl = 'motor_posicion_pd_ao';
if bdIsLoaded(mdl), close_system(mdl,0); end
new_system(mdl);

%% Parametros (Model Workspace)
P = struct( ...
  'Rin',100e3,'R2',100e3,'Cd',2.5e-6,'Rd',10e3,'Rinv',10e3, ...   % PD: Kp = 1, Kd = R2*Cd = 0.25 s
  'Vsat',12,'Aol',1e5, ...
  'Ra',2,'La',1e-3,'Km',0.02,'Jm',5e-5, ...                       % el mismo motor de la practica 1
  'N',20,'Jb',2e-3,'Bf',1e-4, ...                                 % reductora 20:1, brazo y friccion
  'Kpot',10/(1.5*pi));                                            % potenciometro: 10 V en 270 grados
ws = get_param(mdl,'ModelWorkspace');
for f = fieldnames(P)', assignin(ws,f{1},P.(f{1})); end

%% 1-3: referencia (grados) + PD con AO + inversor
U.refsrc(mdl,struct('nombre','Angulo deseado (grados)','valor','90','kv','Kpot*pi/180'));
U.ctrl(mdl,struct('I',false,'D',true,'titulo','Controlador PD'));

%% 4 - Etapa de potencia (x1)
U.addb(mdl,'Voltage-Controlled Voltage Source','Etapa de potencia x1',[1075 370],[50 60]);
U.sp(mdl,'Etapa de potencia x1','K','1');
U.placeAt(mdl,'Etapa de potencia x1','LConn',1,[1060 340]);
U.gnd(mdl,'GND pot',mean([U.pt(mdl,'Etapa de potencia x1','RConn',1); U.pt(mdl,'Etapa de potencia x1','RConn',2)])+[0 32]);
U.W(mdl,{'AO2','RConn',1},{'Etapa de potencia x1','LConn',1});
U.W(mdl,{'Etapa de potencia x1','RConn',1},{'GND pot','LConn',1});
U.W(mdl,{'Etapa de potencia x1','RConn',2},{'GND pot','LConn',1});
U.area(mdl,'4 . Potencia',{'Etapa de potencia x1','GND pot'});

%% 5 - Motor + reductora + brazo
U.addb(mdl,'DC Motor','Motor DC',[1215 375],[60 70]);
U.placeAt(mdl,'Motor DC','LConn',1,[1200 340]);
U.sp(mdl,'Motor DC','Ra','Ra','La','La','La_unit','H','Kv','Km','Kv_unit','V/(rad/s)', ...
    'J','Jm','J_unit','kg*m^2','lam','0','speed0','0');
U.gnd(mdl,'GND motor',U.pt(mdl,'Motor DC','RConn',1)+[0 32]);
U.mref(mdl,'Ref mec 1',U.pt(mdl,'Motor DC','RConn',2)+[0 32]);
U.W(mdl,{'Etapa de potencia x1','LConn',2},{'Motor DC','LConn',1});
U.W(mdl,{'Motor DC','RConn',1},{'GND motor','LConn',1});
U.W(mdl,{'Motor DC','RConn',2},{'Ref mec 1','LConn',1});
U.addb(mdl,'Gear Box','Reductora 20 a 1',[1320 300],[50 40]);
U.sp(mdl,'Reductora 20 a 1','ratio','N');
U.W(mdl,{'Motor DC','LConn',2},{'Reductora 20 a 1','LConn',1});
U.addb(mdl,'Inertia','Brazo (inercia)',[1420 360],[40 40]); U.sp(mdl,'Brazo (inercia)','inertia','Jb');
U.placeAt(mdl,'Brazo (inercia)','LConn',1,[1420 340]);
U.addb(mdl,'Rotational Damper','Friccion',[1500 370],[30 50],'Orientation','down'); U.sp(mdl,'Friccion','D','Bf');
U.placeTop(mdl,'Friccion',[1500 340]);
U.mref(mdl,'Ref mec 2',U.pt(mdl,'Friccion',U.botName(mdl,'Friccion'),1)+[0 32]);
U.addb(mdl,'Ideal Torque Source','Par de carga',[1590 370],[50 60]);
U.placeAt(mdl,'Par de carga','LConn',1,[1590 340]);
U.mref(mdl,'Ref mec 3',U.pt(mdl,'Par de carga','RConn',2)+[0 32]);
U.W(mdl,{'Reductora 20 a 1','RConn',1},{'Brazo (inercia)','LConn',1});
U.W(mdl,{'Brazo (inercia)','LConn',1},{'Friccion',U.topName(mdl,'Friccion'),1});
U.W(mdl,{'Friccion',U.botName(mdl,'Friccion'),1},{'Ref mec 2','LConn',1});
U.W(mdl,{'Friccion',U.topName(mdl,'Friccion'),1},{'Par de carga','LConn',1});
U.W(mdl,{'Par de carga','RConn',2},{'Ref mec 3','LConn',1});
U.addb(mdl,'simulink/Sources/Constant','Par de carga en el brazo (N.m)',[1500 500],[50 30]);
U.sp(mdl,'Par de carga en el brazo (N.m)','Value','0','SampleTime','0.01');
U.gto(mdl,'Goto Tl','Tl',[1560 460]);
U.addb(mdl,'S-PS','S-PS carga',[1570 500],[30 24]);
U.sp(mdl,'S-PS carga','Unit','N*m','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.01');
add_line(mdl,'Par de carga en el brazo (N.m)/1','S-PS carga/1','autorouting','smart');
add_line(mdl,'Par de carga en el brazo (N.m)/1','Goto Tl/1','autorouting','smart');
U.W(mdl,{'S-PS carga','RConn',1},{'Par de carga','RConn',1});
U.area(mdl,'5 . Motor DC + reductora 20 a 1 + brazo',{'Motor DC','GND motor','Ref mec 1','Reductora 20 a 1', ...
    'Brazo (inercia)','Friccion','Ref mec 2','Par de carga','Ref mec 3','Par de carga en el brazo (N.m)','Goto Tl','S-PS carga'});

%% 6 - Potenciometro en el eje del brazo (0..270 grados -> 0..10 V), entra invertido al PD
U.addb(mdl,'Ideal Rotational Motion Sensor','Sensor de angulo',[1720 330],[60 60]);
U.sp(mdl,'Sensor de angulo','position_port','true','velocity_port','false');
U.placeAt(mdl,'Sensor de angulo','LConn',1,[1690 320]);
U.W(mdl,{'Par de carga','LConn',1},{'Sensor de angulo','LConn',1});
x = get_param([mdl '/Sensor de angulo'],'PortHandles');
U.mref(mdl,'Ref mec 4',U.pt(mdl,'Sensor de angulo','RConn',1)+[35 -40]);
U.W(mdl,{'Sensor de angulo','RConn',1},{'Ref mec 4','LConn',1});
kA = numel(x.RConn);                                       % el angulo es el ultimo puerto
U.addb(mdl,'PS Gain','Potenciometro (V por rad)',[1830 330],[40 30]);
U.sp(mdl,'Potenciometro (V por rad)','gain','Kpot','gain_unit','V/rad');
U.W(mdl,{'Sensor de angulo','RConn',kA},{'Potenciometro (V por rad)','LConn',1});
U.addb(mdl,'PS-Simulink Converter','angulo (grados)',[1830 250],[36 24]);
U.sp(mdl,'angulo (grados)','Unit','deg');
U.W(mdl,{'Sensor de angulo','RConn',kA},{'angulo (grados)','LConn',1});
U.gto(mdl,'Goto th','th',U.pt(mdl,'angulo (grados)','Outport',1)+[30 0]);
add_line(mdl,U.ph(mdl,'angulo (grados)','Outport',1),U.ph(mdl,'Goto th','Inport',1));
U.senscvs(mdl,[1960 470]);
U.W(mdl,{'Potenciometro (V por rad)','RConn',1},{'Sensor (invertido)','RConn',1});
U.area(mdl,'6 . Potenciometro (270 grados = 10 V)',{'Sensor de angulo','Ref mec 4','Potenciometro (V por rad)', ...
    'angulo (grados)','Goto th','Sensor (invertido)','GND sensor'});

%% 8 - Tablero en vivo
y0 = 780; H = U;
k1 = H.hmi(mdl,'Knob','Perilla: angulo deseado (grados)',[60 y0 260 y0+200]);
set_param(k1,'Limits',[0 270]);
H.bindParam(k1,[mdl '/Angulo deseado (grados)'],'Value');
s1 = H.hmi(mdl,'Slider','Carga en el brazo (N.m)',[300 y0+60 560 y0+140]);
set_param(s1,'Limits',[-0.3 0.3]);
H.bindParam(s1,[mdl '/Par de carga en el brazo (N.m)'],'Value');
k2 = H.hmi(mdl,'Knob','R2 (Kp = R2 sobre 100k)',[600 y0 790 y0+190]);
set_param(k2,'Limits',[20e3 500e3]);
H.bindParam(k2,[mdl '/R2'],'R');
k3 = H.hmi(mdl,'Knob','Cd en faradios (Kd = R2 x Cd)',[820 y0 1010 y0+190]);
set_param(k3,'Limits',[0.01e-6 10e-6]);
H.bindParam(k3,[mdl '/Cd'],'c');
g1 = H.hmi(mdl,'Gauge','Angulo del brazo (grados)',[1050 y0 1270 y0+220]);
set_param(g1,'Limits',[0 270]);
H.bindSig(g1,[mdl '/angulo (grados)']);
g2 = H.hmi(mdl,'Half Gauge','Medidor de u (V)',[1300 y0 1500 y0+120]);
set_param(g2,'Limits',[-12 12]);
H.bindSig(g2,[mdl '/u (V)']);
H.fro(mdl,'From u sat','u',[1250 y0+235]);
H.addb(mdl,'simulink/Math Operations/Abs','abs u',[1320 y0+235],[30 26]);
H.addb(mdl,'simulink/Logic and Bit Operations/Compare To Constant','AO saturado?',[1400 y0+235],[60 36]);
set_param([mdl '/AO saturado?'],'relop','>=','const','0.98*Vsat');
H.addb(mdl,'simulink/Sinks/Terminator','Term sat',[1470 y0+235],[16 16]);
add_line(mdl,'From u sat/1','abs u/1'); add_line(mdl,'abs u/1','AO saturado?/1');
add_line(mdl,'AO saturado?/1','Term sat/1');
l1 = H.hmi(mdl,'Lamp','AO saturado',[1540 y0+30 1620 y0+110]);
H.bindSig(l1,[mdl '/AO saturado?']);
set_param(l1,'StateColors',struct('Value',{0,1},'Color',{[0.82 0.82 0.80],[0.85 0.20 0.15]}));
U.areaBox(mdl,'8 . Tablero en vivo - mueve las perillas mientras simula',[30 y0-45 1650 y0+270]);

%% 10 - Osciloscopios en el lienzo
y1 = y0 + 330;
U.probe(mdl,'s_ref','Vref','180/pi/Kpot',[60 y1+290],'Angulo deseado (grados)');
U.probe(mdl,'s_med','th','1',[60 y1+330],'Angulo medido (grados)');
U.probe(mdl,'s_pert','Tl','1',[60 y1+370],'Par de carga (N.m)');
U.probe(mdl,'s_u','u','1',[60 y1+410],'Esfuerzo de control u (V)');
U.dscope(mdl,'Referencia vs angulo medido (grados)',[60 y1 600 y1+240],{'s_ref','s_med'},10,[-20 290]);
U.dscope(mdl,'Perturbacion: par de carga en el brazo (N.m)',[640 y1 1100 y1+240],{'s_pert'},10,[-0.35 0.35]);
U.dscope(mdl,'Esfuerzo de control u (V)',[1140 y1 1620 y1+240],{'s_u'},10,[-13 13]);
U.areaBox(mdl,'10 . Osciloscopios en vivo',[30 y1-45 1650 y1+450]);

%% 9 - Brazo 3D sobre un dial (Multibody): brazo rojo = medido, aguja verde = deseado
x0 = 1720; y2 = 760;
U.addb(mdl,'World Frame','Mundo',[x0+40 y2+60],[40 40]);
U.addb(mdl,'Mechanism Configuration','Config mecanismo',[x0+40 y2+140],[40 40]);
U.addb(mdl,'Solver Configuration','Solver 3D',[x0+40 y2+210],[40 30]);
U.mb(mdl,'Mundo','','Config mecanismo',''); U.mb(mdl,'Mundo','','Solver 3D','');
rt(U,mdl,'Dial vertical (de frente)',[x0+100 y2+60],'[0 0 0]','+X','90');
U.mb(mdl,'Mundo','','Dial vertical (de frente)','B');
U.addb(mdl,'Cylindrical Solid','Dial',[x0+170 y2+40],[50 50]);
U.sp(mdl,'Dial','CylinderRadius','0.16','CylinderLength','0.01','GraphicDiffuseColor','[0.93 0.93 0.90]');
U.mb(mdl,'Dial vertical (de frente)','F','Dial','');
ang = [0 90 180 270];
for i = 1:4
    n = sprintf('Marca %d grados',ang(i));
    rt(U,mdl,['Pos ' n],[x0+170+60*(i-1) y2+320],sprintf('[%g %g 0.007]',0.145*cosd(ang(i)),0.145*sind(ang(i))),'+Z',num2str(ang(i)));
    U.mb(mdl,'Dial vertical (de frente)','F',['Pos ' n],'B');
    U.addb(mdl,'Brick Solid',n,[x0+170+60*(i-1) y2+390],[40 40]);
    U.sp(mdl,n,'BrickDimensions','[0.03 0.006 0.004]','GraphicDiffuseColor','[0.2 0.2 0.2]');
    U.mb(mdl,['Pos ' n],'F',n,'');
end
rt(U,mdl,'Sobre el dial',[x0+170 y2+130],'[0 0 0.008]','','0');
U.mb(mdl,'Dial vertical (de frente)','F','Sobre el dial','B');
U.addb(mdl,'Revolute Joint','Eje del brazo',[x0+280 y2+100],[60 60]);
U.sp(mdl,'Eje del brazo','MotionActuationMode','InputMotion','TorqueActuationMode','ComputedTorque');
U.mb(mdl,'Sobre el dial','F','Eje del brazo','B');
rt(U,mdl,'Centro brazo',[x0+380 y2+100],'[0.065 0 0.004]','','0');
U.mb(mdl,'Eje del brazo','F','Centro brazo','B');
U.addb(mdl,'Brick Solid','Brazo',[x0+470 y2+100],[50 50]);
U.sp(mdl,'Brazo','BrickDimensions','[0.15 0.022 0.008]','GraphicDiffuseColor','[0.78 0.20 0.15]');
U.mb(mdl,'Centro brazo','F','Brazo','');
U.addb(mdl,'Cylindrical Solid','Eje',[x0+470 y2+30],[40 40]);
U.sp(mdl,'Eje','CylinderRadius','0.015','CylinderLength','0.02','GraphicDiffuseColor','[0.15 0.15 0.15]');
U.mb(mdl,'Eje del brazo','F','Eje','');
U.addb(mdl,'Revolute Joint','Eje referencia',[x0+280 y2+210],[60 60]);
U.sp(mdl,'Eje referencia','MotionActuationMode','InputMotion','TorqueActuationMode','ComputedTorque');
U.mb(mdl,'Sobre el dial','F','Eje referencia','B');
rt(U,mdl,'Centro aguja ref',[x0+380 y2+210],'[0.07 0 0.012]','','0');
U.mb(mdl,'Eje referencia','F','Centro aguja ref','B');
U.addb(mdl,'Brick Solid','Aguja de referencia',[x0+470 y2+210],[50 50]);
U.sp(mdl,'Aguja de referencia','BrickDimensions','[0.16 0.008 0.004]','GraphicDiffuseColor','[0.49 0.60 0.24]', ...
    'GraphicOpacity','0.6','Density','1');
U.mb(mdl,'Centro aguja ref','F','Aguja de referencia','');
% senales que mueven la animacion
U.fro(mdl,'From th 3D','th',[x0+40 y2+470]);
U.addb(mdl,'simulink/Math Operations/Gain','grados a rad',[x0+120 y2+470],[40 30]);
U.sp(mdl,'grados a rad','Gain','pi/180');
U.addb(mdl,'S-PS','S-PS brazo',[x0+190 y2+470],[30 24]);
U.sp(mdl,'S-PS brazo','Unit','rad','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.005','SimscapeFilterOrder','2');
add_line(mdl,'From th 3D/1','grados a rad/1','autorouting','smart');
add_line(mdl,'grados a rad/1','S-PS brazo/1','autorouting','smart');
U.W(mdl,{'S-PS brazo','RConn',1},{'Eje del brazo','LConn',2});
U.fro(mdl,'From Vref 3D','Vref',[x0+40 y2+540]);
U.addb(mdl,'simulink/Math Operations/Gain','V a rad',[x0+120 y2+540],[40 30]);
U.sp(mdl,'V a rad','Gain','1/Kpot');
U.addb(mdl,'S-PS','S-PS ref 3D',[x0+190 y2+540],[30 24]);
U.sp(mdl,'S-PS ref 3D','Unit','rad','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.05','SimscapeFilterOrder','2');
add_line(mdl,'From Vref 3D/1','V a rad/1','autorouting','smart');
add_line(mdl,'V a rad/1','S-PS ref 3D/1','autorouting','smart');
U.W(mdl,{'S-PS ref 3D','RConn',1},{'Eje referencia','LConn',2});
U.areaBox(mdl,'9 . Brazo 3D (Multibody): rojo = medido, verde = deseado',[x0-20 y2-50 x0+540 y2+590]);

%% Simulacion en tiempo real
set_param(mdl,'StopTime','inf','Solver','ode23t','MaxStep','0.005','EnablePacing','on','PacingRate',1, ...
    'SignalLogging','on','ReturnWorkspaceOutputs','on');
U.check(mdl);
carpeta = fileparts(mfilename('fullpath'));
save_system(mdl,fullfile(carpeta,[mdl '.slx']));
fprintf('Practica 4 lista: abre %s.slx y dale Run (vista Front en el Multibody Explorer).\n',mdl);

function rt(U,mdl,name,ctr,tr,eje,ang)
U.addb(mdl,'Rigid Transform',name,ctr,[40 40]);
U.sp(mdl,name,'TranslationMethod','Cartesian','TranslationCartesianOffset',tr);
if ~isempty(eje)
    U.sp(mdl,name,'RotationMethod','StandardAxis','RotationStandardAxis',eje,'RotationAngle',ang);
end
end
