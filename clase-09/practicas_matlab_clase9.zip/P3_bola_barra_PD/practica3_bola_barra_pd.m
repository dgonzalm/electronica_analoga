%% practica3_bola_barra_pd.m - Electronica Analogica (UNAL) - Clase 9
% PRACTICA 3 - BOLA EN LA BARRA con un controlador PD hecho con AO.
%   La planta es fisica: Simscape Multibody (barra que gira con un servo y una
%   bola que se desliza por gravedad). Sin accion derivativa la bola oscila de
%   lado a lado sin parar: el PD (rama Rd-Cd) es el que la frena y la detiene.
%   Tablero en vivo + osciloscopios en el lienzo; la animacion 3D ES la planta.
U = ea_lib();
mdl = 'bola_barra_pd_ao';
if bdIsLoaded(mdl), close_system(mdl,0); end
new_system(mdl);

%% Parametros (Model Workspace)
P = struct( ...
  'Rin',100e3,'R2',330e3,'Cd',6.8e-6,'Rd',1e3,'Rinv',10e3, ...  % PD: Kp = 3.3, Kd = R2*Cd = 2.2 s
  'Vsat',12,'Aol',1e5, ...
  'Ks',10, ...          % sensor de posicion: 10 V/m  (0.1 V por cm)
  'Kserv',0.02, ...     % servo: 0.02 rad por voltio (12 V -> 14 grados)
  'Tserv',0.05, ...     % retardo del servo (s)
  'Lb',1.0);            % largo de la barra (m)
ws = get_param(mdl,'ModelWorkspace');
for f = fieldnames(P)', assignin(ws,f{1},P.(f{1})); end

%% 1-3: referencia (cm) + PD con AO + inversor
U.refsrc(mdl,struct('nombre','Posicion deseada (cm)','valor','0','kv','0.01*Ks'));
U.ctrl(mdl,struct('I',false,'D',true,'titulo','Controlador PD'));

%% 4 - Servo que inclina la barra
U.fro(mdl,'From u servo','u',[1080 470]);
U.addb(mdl,'simulink/Math Operations/Gain','Servo (rad por V)',[1160 470],[40 30]);
U.sp(mdl,'Servo (rad por V)','Gain','-Kserv');     % u>0 baja el extremo derecho
U.addb(mdl,'simulink/Continuous/Transfer Fcn','retardo del servo',[1250 470],[60 36]);
U.sp(mdl,'retardo del servo','Numerator','1','Denominator','[Tserv 1]');
U.gto(mdl,'Goto theta','theta',[1300 430]);
U.addb(mdl,'S-PS','S-PS angulo',[1330 470],[30 24]);
U.sp(mdl,'S-PS angulo','Unit','rad','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.01','SimscapeFilterOrder','2');
add_line(mdl,'From u servo/1','Servo (rad por V)/1','autorouting','smart');
add_line(mdl,'Servo (rad por V)/1','retardo del servo/1','autorouting','smart');
add_line(mdl,'retardo del servo/1','S-PS angulo/1','autorouting','smart');
add_line(mdl,'retardo del servo/1','Goto theta/1','autorouting','smart');
U.area(mdl,'4 . Servo: el esfuerzo u inclina la barra',{'From u servo','Servo (rad por V)','retardo del servo','Goto theta','S-PS angulo'});

%% 5 - Planta fisica en Multibody (gravedad hacia -z: la vista "Front" muestra el plano x-z)
x0 = 1420; y2 = 200;
U.addb(mdl,'World Frame','Mundo',[x0+40 y2+60],[40 40]);
U.addb(mdl,'Mechanism Configuration','Config mecanismo',[x0+40 y2+140],[40 40]);
U.sp(mdl,'Config mecanismo','GravityVector','[0 0 -9.80665]');
% (sin Solver propio: el sensor de posicion une la red 3D con la red electrica)
U.mb(mdl,'Mundo','','Config mecanismo','');
U.addb(mdl,'Revolute Joint','Pivote de la barra',[x0+160 y2+60],[60 60]);
U.sp(mdl,'Pivote de la barra','MotionActuationMode','InputMotion','TorqueActuationMode','ComputedTorque');
rt(U,mdl,'Eje de giro (horizontal)',[x0+100 y2+60],'[0 0 0]','+X','90');
U.mb(mdl,'Mundo','','Eje de giro (horizontal)','B');
U.mb(mdl,'Eje de giro (horizontal)','F','Pivote de la barra','B');
U.W(mdl,{'S-PS angulo','RConn',1},{'Pivote de la barra','LConn',2});
U.addb(mdl,'Brick Solid','Barra',[x0+280 y2+20],[50 50]);
U.sp(mdl,'Barra','BrickDimensions','[Lb 0.02 0.04]','GraphicDiffuseColor','[0.49 0.60 0.24]');
U.mb(mdl,'Pivote de la barra','F','Barra','');
rt(U,mdl,'Riel (sobre la barra)',[x0+280 y2+110],'[0 0.035 0]','+Y','90');
U.mb(mdl,'Pivote de la barra','F','Riel (sobre la barra)','B');
U.addb(mdl,'Prismatic Joint','Bola (desliza)',[x0+390 y2+110],[60 60]);
U.sp(mdl,'Bola (desliza)','TorqueActuationMode','InputTorque','MotionActuationMode','ComputedMotion', ...
    'SensePosition','on','PositionTargetSpecify','on','PositionTargetValue','-0.3','DampingCoefficient','0.02', ...
    'LowerLimitSpecify','on','LowerLimitBound','-0.48','UpperLimitSpecify','on','UpperLimitBound','0.48');
U.mb(mdl,'Riel (sobre la barra)','F','Bola (desliza)','B');
U.addb(mdl,'Spherical Solid','Bola',[x0+500 y2+110],[50 50]);
U.sp(mdl,'Bola','SphereRadius','0.025','GraphicDiffuseColor','[0.78 0.20 0.15]');
U.mb(mdl,'Bola (desliza)','F','Bola','');
U.addb(mdl,'Prismatic Joint','Referencia (fantasma)',[x0+390 y2+210],[60 60]);
U.sp(mdl,'Referencia (fantasma)','MotionActuationMode','InputMotion','TorqueActuationMode','ComputedTorque');
U.mb(mdl,'Riel (sobre la barra)','F','Referencia (fantasma)','B');
U.addb(mdl,'Spherical Solid','Bola fantasma',[x0+500 y2+210],[50 50]);
U.sp(mdl,'Bola fantasma','SphereRadius','0.027','GraphicDiffuseColor','[0.49 0.60 0.24]','GraphicOpacity','0.3', ...
    'Density','1');
U.mb(mdl,'Referencia (fantasma)','F','Bola fantasma','');
rt(U,mdl,'Pos soporte',[x0+160 y2+300],'[0 0 -0.13]','','0');
U.mb(mdl,'Mundo','','Pos soporte','B');
U.addb(mdl,'Brick Solid','Soporte',[x0+280 y2+300],[50 50]);
U.sp(mdl,'Soporte','BrickDimensions','[0.06 0.06 0.22]','GraphicDiffuseColor','[0.30 0.31 0.32]');
U.mb(mdl,'Pos soporte','F','Soporte','');
% referencia que mueve la bola fantasma
U.fro(mdl,'From Vref 3D','Vref',[x0+160 y2+400]);
U.addb(mdl,'simulink/Math Operations/Gain','V a metros',[x0+240 y2+400],[40 30]);
U.sp(mdl,'V a metros','Gain','1/Ks');
U.addb(mdl,'S-PS','S-PS ref 3D',[x0+310 y2+400],[30 24]);
U.sp(mdl,'S-PS ref 3D','Unit','m','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.05','SimscapeFilterOrder','2');
add_line(mdl,'From Vref 3D/1','V a metros/1','autorouting','smart');
add_line(mdl,'V a metros/1','S-PS ref 3D/1','autorouting','smart');
U.W(mdl,{'S-PS ref 3D','RConn',1},{'Referencia (fantasma)','LConn',2});
% perturbacion: empujon a la bola (fuerza a lo largo de la barra)
U.addb(mdl,'simulink/Sources/Constant','Empujon (N)',[x0+160 y2+470],[50 30]);
U.sp(mdl,'Empujon (N)','Value','0','SampleTime','0.01');
U.gto(mdl,'Goto F','F',[x0+215 y2+440]);
U.addb(mdl,'S-PS','S-PS empujon',[x0+250 y2+470],[30 24]);
U.sp(mdl,'S-PS empujon','Unit','N','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.02');
add_line(mdl,'Empujon (N)/1','S-PS empujon/1','autorouting','smart');
add_line(mdl,'Empujon (N)/1','Goto F/1','autorouting','smart');
U.W(mdl,{'S-PS empujon','RConn',1},{'Bola (desliza)','LConn',2});
U.areaBox(mdl,'5 . Planta fisica 3D (Multibody): barra + bola + gravedad',[x0-20 y2-45 x0+560 y2+510]);

%% 6 - Sensor de posicion de la bola: 10 V/m (entra invertido al PD)
U.addb(mdl,'PS Gain','Sensor 10 V por m',[x0+640 y2+150],[40 30]);
U.sp(mdl,'Sensor 10 V por m','gain','Ks','gain_unit','V/m');
U.W(mdl,{'Bola (desliza)','RConn',2},{'Sensor 10 V por m','LConn',1});
U.addb(mdl,'PS-Simulink Converter','x (cm)',[x0+640 y2+60],[36 24]);
U.sp(mdl,'x (cm)','Unit','cm');
U.W(mdl,{'Bola (desliza)','RConn',2},{'x (cm)','LConn',1});
U.gto(mdl,'Goto x','x',U.pt(mdl,'x (cm)','Outport',1)+[30 0]);
add_line(mdl,U.ph(mdl,'x (cm)','Outport',1),U.ph(mdl,'Goto x','Inport',1));
U.senscvs(mdl,[x0+760 y2+290]);
U.W(mdl,{'Sensor 10 V por m','RConn',1},{'Sensor (invertido)','RConn',1});
U.area(mdl,'6 . Sensor de posicion (10 V por m)',{'Sensor 10 V por m','x (cm)','Goto x','Sensor (invertido)','GND sensor'});

%% 8 - Tablero en vivo
y0 = 820; H = U;
k1 = H.hmi(mdl,'Knob','Perilla: posicion deseada (cm)',[60 y0 260 y0+200]);
set_param(k1,'Limits',[-40 40]);
H.bindParam(k1,[mdl '/Posicion deseada (cm)'],'Value');
s1 = H.hmi(mdl,'Slider','Empujon a la bola (N)',[300 y0+60 560 y0+140]);
set_param(s1,'Limits',[-0.05 0.05]);
H.bindParam(s1,[mdl '/Empujon (N)'],'Value');
k2 = H.hmi(mdl,'Knob','R2 (Kp = R2 sobre 100k)',[600 y0 790 y0+190]);
set_param(k2,'Limits',[50e3 1e6]);
H.bindParam(k2,[mdl '/R2'],'R');
k3 = H.hmi(mdl,'Knob','Cd en faradios (Kd = R2 x Cd)',[820 y0 1010 y0+190]);
set_param(k3,'Limits',[0.1e-6 20e-6]);
H.bindParam(k3,[mdl '/Cd'],'c');
g1 = H.hmi(mdl,'Linear Gauge','Posicion de la bola (cm)',[1050 y0+40 1350 y0+140]);
set_param(g1,'Limits',[-50 50]);
H.bindSig(g1,[mdl '/x (cm)']);
H.fro(mdl,'From theta g','theta',[1060 y0+200]);
H.addb(mdl,'simulink/Math Operations/Gain','grados barra',[1130 y0+200],[40 30]);
H.sp(mdl,'grados barra','Gain','180/pi');
H.addb(mdl,'simulink/Sinks/Terminator','Term g',[1190 y0+200],[16 16]);
add_line(mdl,'From theta g/1','grados barra/1'); add_line(mdl,'grados barra/1','Term g/1');
g2 = H.hmi(mdl,'Half Gauge','Inclinacion de la barra (grados)',[1380 y0 1580 y0+120]);
set_param(g2,'Limits',[-15 15]);
H.bindSig(g2,[mdl '/grados barra']);
H.fro(mdl,'From u sat','u',[1250 y0+235]);
H.addb(mdl,'simulink/Math Operations/Abs','abs u',[1320 y0+235],[30 26]);
H.addb(mdl,'simulink/Logic and Bit Operations/Compare To Constant','AO saturado?',[1400 y0+235],[60 36]);
set_param([mdl '/AO saturado?'],'relop','>=','const','0.98*Vsat');
H.addb(mdl,'simulink/Sinks/Terminator','Term sat',[1470 y0+235],[16 16]);
add_line(mdl,'From u sat/1','abs u/1'); add_line(mdl,'abs u/1','AO saturado?/1');
add_line(mdl,'AO saturado?/1','Term sat/1');
l1 = H.hmi(mdl,'Lamp','AO saturado',[1610 y0+30 1690 y0+110]);
H.bindSig(l1,[mdl '/AO saturado?']);
set_param(l1,'StateColors',struct('Value',{0,1},'Color',{[0.82 0.82 0.80],[0.85 0.20 0.15]}));
U.areaBox(mdl,'8 . Tablero en vivo - mueve las perillas mientras simula',[30 y0-45 1720 y0+270]);

%% 10 - Osciloscopios en el lienzo
y1 = y0 + 330;
U.probe(mdl,'s_ref','Vref','100/Ks',[60 y1+290],'Posicion deseada (cm)');
U.probe(mdl,'s_med','x','1',[60 y1+330],'Posicion medida (cm)');
U.probe(mdl,'s_pert','F','1',[60 y1+370],'Empujon (N)');
U.probe(mdl,'s_u','u','1',[60 y1+410],'Esfuerzo de control u (V)');
U.dscope(mdl,'Referencia vs posicion medida (cm)',[60 y1 640 y1+240],{'s_ref','s_med'},20,[-50 50]);
U.dscope(mdl,'Perturbacion: empujon a la bola (N)',[680 y1 1140 y1+240],{'s_pert'},20,[-0.06 0.06]);
U.dscope(mdl,'Esfuerzo de control u (V)',[1180 y1 1690 y1+240],{'s_u'},20,[-13 13]);
U.areaBox(mdl,'10 . Osciloscopios en vivo',[30 y1-45 1720 y1+450]);

%% Simulacion en tiempo real
set_param(mdl,'StopTime','inf','Solver','ode23t','MaxStep','0.01','EnablePacing','on','PacingRate',1, ...
    'SignalLogging','on','ReturnWorkspaceOutputs','on');
U.check(mdl);
carpeta = fileparts(mfilename('fullpath'));
save_system(mdl,fullfile(carpeta,[mdl '.slx']));
fprintf('Practica 3 lista: abre %s.slx y dale Run (vista Front en el Multibody Explorer).\n',mdl);

function rt(U,mdl,name,ctr,tr,eje,ang)
U.addb(mdl,'Rigid Transform',name,ctr,[40 40]);
U.sp(mdl,name,'TranslationMethod','Cartesian','TranslationCartesianOffset',tr);
if ~isempty(eje)
    U.sp(mdl,name,'RotationMethod','StandardAxis','RotationStandardAxis',eje,'RotationAngle',ang);
end
end
