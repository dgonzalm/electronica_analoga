%% practica2_horno_pid.m - Electronica Analogica (UNAL) - Clase 9
% PRACTICA 2 - Control de TEMPERATURA de un horno con un PID hecho con AO.
%   Planta (Simscape termico): resistencia calefactora -> masa del horno ->
%   perdidas al ambiente; el sensor esta dentro de una vaina (segunda masa
%   termica) y por eso "llega tarde": ahi es donde la accion DERIVATIVA ayuda.
%   Controlador: PID compacto con 1 AO + inversor (Clase 8 + rama derivativa
%   Rd-Cd sobre la medicion).  Perturbacion: abrir la puerta (perdida de calor).
%   Tablero en vivo + osciloscopios en el lienzo + horno 3D (puerta y termometro).
U = ea_lib();
mdl = 'horno_pid_ao';
if bdIsLoaded(mdl), close_system(mdl,0); end
new_system(mdl);

%% Parametros (Model Workspace)
P = struct( ...
  'Rin',100e3,'R2',500e3,'C2',20e-6,'Cd',3e-6,'Rd',10e3,'Rinv',10e3, ... % PID: Kp=5, Ti=10 s, Kd=1.5 s
  'Vsat',12,'Aol',1e5, ...
  'Kh',16.7, ...          % W por voltio: etapa de potencia de la resistencia (200 W a 12 V)
  'Ktr',0.1, ...          % transmisor de temperatura: 0.1 V/degC  (0..120 degC -> 0..12 V)
  'Tamb',25, ...          % degC
  'Mh',0.02,'ch',500, ... % horno de laboratorio: 0.02 kg x 500 J/(kg K) = 10 J/K
  'Ms',0.002,'cs',500, ... % vaina del sensor: 1 J/K
  'kamb',1,'ksen',2);     % conductancias: 1 W/K al ambiente, 2 W/K horno->sensor
ws = get_param(mdl,'ModelWorkspace');
for f = fieldnames(P)', assignin(ws,f{1},P.(f{1})); end

%% 1-3: referencia + PID con AO + inversor
U.refsrc(mdl,struct('nombre','Temperatura deseada (degC)','valor','60','kv','Ktr'));
U.ctrl(mdl,struct('I',true,'D',true,'titulo','Controlador PID'));

%% 4 - Etapa de potencia: la resistencia solo calienta (u>0)
U.fro(mdl,'From u pot','u',[1060 470]);
U.addb(mdl,'simulink/Discontinuities/Saturation','solo calienta (u>0)',[1125 470],[40 30]);
U.sp(mdl,'solo calienta (u>0)','UpperLimit','Vsat','LowerLimit','0');
U.addb(mdl,'simulink/Math Operations/Gain','Kh (W por V)',[1190 470],[40 30]);
U.sp(mdl,'Kh (W por V)','Gain','Kh');
U.gto(mdl,'Goto P','P',[1240 430]);
U.addb(mdl,'S-PS','S-PS calor',[1255 470],[30 24]);
U.sp(mdl,'S-PS calor','Unit','W','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.05');
add_line(mdl,'From u pot/1','solo calienta (u>0)/1','autorouting','smart');
add_line(mdl,'solo calienta (u>0)/1','Kh (W por V)/1','autorouting','smart');
add_line(mdl,'Kh (W por V)/1','S-PS calor/1','autorouting','smart');
add_line(mdl,'Kh (W por V)/1','Goto P/1','autorouting','smart');

%% 5 - Planta termica
U.addb(mdl,'Controlled Heat Flow Rate Source','Resistencia calefactora',[1360 400],[40 50]);
U.addb(mdl,'Thermal Mass','Masa del horno',[1470 300],[50 40]);
U.sp(mdl,'Masa del horno','mass','Mh','sp_heat','ch','T_specify','on','T','Tamb','T_unit','degC');
U.addb(mdl,'Conductive Heat Transfer','Perdidas al ambiente',[1560 240],[50 30]);
U.sp(mdl,'Perdidas al ambiente','area','0.01','thickness','0.01','th_cond','kamb');
U.addb(mdl,'Thermal Mass','Ambiente (25 degC)',[1660 200],[50 40]);
U.sp(mdl,'Ambiente (25 degC)','mass','1e6','sp_heat','1000','T_specify','on','T','Tamb','T_unit','degC');
U.addb(mdl,'Thermal Reference','Ref termica',[1360 500],[30 30]);
U.addb(mdl,'Controlled Heat Flow Rate Source','Puerta abierta (perdida)',[1470 420],[40 50]);
U.addb(mdl,'Conductive Heat Transfer','Vaina del sensor',[1560 340],[50 30]);
U.sp(mdl,'Vaina del sensor','area','0.01','thickness','0.01','th_cond','ksen');
U.addb(mdl,'Thermal Mass','Sensor (dentro de la vaina)',[1660 340],[50 40]);
U.sp(mdl,'Sensor (dentro de la vaina)','mass','Ms','sp_heat','cs','T_specify','on','T','Tamb','T_unit','degC');
% fuente de calor: (A) LConn1 arriba, (S) RConn1, (B) RConn2. Con S>0 el calor entra al nodo conectado en A
U.W(mdl,{'Resistencia calefactora','LConn',1},{'Masa del horno','LConn',1});
U.W(mdl,{'Resistencia calefactora','RConn',2},{'Ref termica','LConn',1});
U.W(mdl,{'S-PS calor','RConn',1},{'Resistencia calefactora','RConn',1});
U.W(mdl,{'Masa del horno','LConn',1},{'Perdidas al ambiente','LConn',1});
U.W(mdl,{'Perdidas al ambiente','RConn',1},{'Ambiente (25 degC)','LConn',1});
U.W(mdl,{'Masa del horno','LConn',1},{'Vaina del sensor','LConn',1});
U.W(mdl,{'Vaina del sensor','RConn',1},{'Sensor (dentro de la vaina)','LConn',1});
U.W(mdl,{'Puerta abierta (perdida)','LConn',1},{'Masa del horno','LConn',1});
U.W(mdl,{'Puerta abierta (perdida)','RConn',2},{'Ref termica','LConn',1});
U.addb(mdl,'Solver Configuration','Solver termico',[1360 560],[40 30]);
U.W(mdl,{'Solver termico','RConn',1},{'Ref termica','LConn',1});
% perturbacion: constante (la mueve el deslizador) -> calor que se pierde por la puerta
U.addb(mdl,'simulink/Sources/Constant','Puerta abierta (W)',[1360 640],[50 30]);
U.sp(mdl,'Puerta abierta (W)','Value','0','SampleTime','0.1');
U.gto(mdl,'Goto Qp','Qp',[1420 600]);
U.addb(mdl,'simulink/Math Operations/Gain','sale calor',[1430 640],[30 30]);
U.sp(mdl,'sale calor','Gain','-1');
U.addb(mdl,'S-PS','S-PS puerta',[1490 640],[30 24]);
U.sp(mdl,'S-PS puerta','Unit','W','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.5');
add_line(mdl,'Puerta abierta (W)/1','sale calor/1','autorouting','smart');
add_line(mdl,'Puerta abierta (W)/1','Goto Qp/1','autorouting','smart');
add_line(mdl,'sale calor/1','S-PS puerta/1','autorouting','smart');
U.W(mdl,{'S-PS puerta','RConn',1},{'Puerta abierta (perdida)','RConn',1});
U.area(mdl,'4 . Potencia: la resistencia solo calienta',{'From u pot','solo calienta (u>0)','Kh (W por V)','Goto P','S-PS calor'});
U.area(mdl,'5 . Horno (planta termica) y perturbacion',{'Resistencia calefactora','Masa del horno','Perdidas al ambiente', ...
    'Ambiente (25 degC)','Ref termica','Puerta abierta (perdida)','Vaina del sensor','Sensor (dentro de la vaina)', ...
    'Solver termico','Puerta abierta (W)','Goto Qp','sale calor','S-PS puerta'});

%% 6 - Sensor + transmisor 0.1 V/degC (entra invertido al PID)
U.addb(mdl,'Temperature Sensor','Termometro',[1790 340],[40 40]);
U.W(mdl,{'Sensor (dentro de la vaina)','LConn',1},{'Termometro','LConn',1});
U.addb(mdl,'Thermal Reference','Ref termica 2',[1840 420],[30 30]);
U.addb(mdl,'PS-Simulink Converter','T (degC)',[1880 340],[36 24]);
U.sp(mdl,'T (degC)','Unit','degC','AffineConversion','on');
try   % T sale por RConn1 y B por RConn2 (si no, al reves)
    U.W(mdl,{'Termometro','RConn',1},{'T (degC)','LConn',1});
    U.W(mdl,{'Termometro','RConn',2},{'Ref termica 2','LConn',1});
catch
    U.W(mdl,{'Termometro','RConn',2},{'T (degC)','LConn',1});
    U.W(mdl,{'Termometro','RConn',1},{'Ref termica 2','LConn',1});
end
U.gto(mdl,'Goto T','T',U.pt(mdl,'T (degC)','Outport',1)+[30 -40]);
add_line(mdl,U.ph(mdl,'T (degC)','Outport',1),U.ph(mdl,'Goto T','Inport',1),'autorouting','smart');
U.addb(mdl,'simulink/Math Operations/Gain','Transmisor (0.1 V por degC)',[1960 400],[40 30]);
U.sp(mdl,'Transmisor (0.1 V por degC)','Gain','Ktr');
add_line(mdl,U.ph(mdl,'T (degC)','Outport',1),U.ph(mdl,'Transmisor (0.1 V por degC)','Inport',1),'autorouting','smart');
U.addb(mdl,'S-PS','S-PS sensor',[2030 400],[30 24]);
U.sp(mdl,'S-PS sensor','Unit','V','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.01');
add_line(mdl,'Transmisor (0.1 V por degC)/1','S-PS sensor/1','autorouting','smart');
U.senscvs(mdl,[2110 470]);
U.W(mdl,{'S-PS sensor','RConn',1},{'Sensor (invertido)','RConn',1});
U.area(mdl,'6 . Sensor de temperatura y transmisor',{'Termometro','Ref termica 2','T (degC)','Goto T', ...
    'Transmisor (0.1 V por degC)','S-PS sensor','Sensor (invertido)','GND sensor'});

%% 8 - Tablero en vivo
y0 = 780; H = U;
k1 = H.hmi(mdl,'Knob','Perilla: temperatura deseada (degC)',[60 y0 260 y0+200]);
set_param(k1,'Limits',[25 150]);
H.bindParam(k1,[mdl '/Temperatura deseada (degC)'],'Value');
s1 = H.hmi(mdl,'Slider','Abrir la puerta: calor que se pierde (W)',[300 y0+60 560 y0+140]);
set_param(s1,'Limits',[0 80]);
H.bindParam(s1,[mdl '/Puerta abierta (W)'],'Value');
k2 = H.hmi(mdl,'Knob','R2 (Kp = R2 sobre 100k)',[600 y0 790 y0+190]);
set_param(k2,'Limits',[100e3 2e6]);
H.bindParam(k2,[mdl '/R2'],'R');
k3 = H.hmi(mdl,'Knob','Cd en faradios (Kd = R2 x Cd)',[820 y0 1010 y0+190]);
set_param(k3,'Limits',[0.1e-6 10e-6]);
H.bindParam(k3,[mdl '/Cd'],'c');
g1 = H.hmi(mdl,'Gauge','Temperatura del sensor (degC)',[1050 y0 1270 y0+220]);
set_param(g1,'Limits',[0 150]);
H.bindSig(g1,[mdl '/T (degC)']);
g2 = H.hmi(mdl,'Half Gauge','Potencia de la resistencia (W)',[1300 y0 1500 y0+120]);
set_param(g2,'Limits',[0 200]);
H.bindSig(g2,[mdl '/Kh (W por V)']);
H.fro(mdl,'From u sat','u',[1310 y0+200]);
H.addb(mdl,'simulink/Logic and Bit Operations/Compare To Constant','AO saturado?',[1390 y0+200],[60 36]);
set_param([mdl '/AO saturado?'],'relop','>=','const','0.98*Vsat');
H.addb(mdl,'simulink/Sinks/Terminator','Term sat',[1460 y0+200],[16 16]);
add_line(mdl,'From u sat/1','AO saturado?/1'); add_line(mdl,'AO saturado?/1','Term sat/1');
l1 = H.hmi(mdl,'Lamp','AO saturado',[1530 y0+30 1610 y0+110]);
H.bindSig(l1,[mdl '/AO saturado?']);
set_param(l1,'StateColors',struct('Value',{0,1},'Color',{[0.82 0.82 0.80],[0.85 0.20 0.15]}));
U.areaBox(mdl,'8 . Tablero en vivo - mueve las perillas mientras simula',[30 y0-45 1640 y0+260]);

%% 10 - Osciloscopios en el lienzo (referencia vs medida, perturbacion, esfuerzo)
y1 = y0 + 320;
U.probe(mdl,'s_ref','Vref','1/Ktr',[60 y1+290],'Temperatura deseada (degC)','0.02');
U.probe(mdl,'s_med','T','1',[60 y1+330],'Temperatura medida (degC)','0.02');
U.probe(mdl,'s_pert','Qp','1',[60 y1+370],'Perdida por la puerta (W)','0.02');
U.probe(mdl,'s_u','u','1',[60 y1+410],'Esfuerzo de control u (V)','0.02');
U.dscope(mdl,'Referencia vs temperatura medida (degC)',[60 y1 600 y1+240],{'s_ref','s_med'},30,[20 160]);
U.dscope(mdl,'Perturbacion: calor perdido por la puerta (W)',[640 y1 1080 y1+240],{'s_pert'},30,[-5 85]);
U.dscope(mdl,'Esfuerzo de control u (V)',[1120 y1 1600 y1+240],{'s_u'},30,[-13 13]);
U.areaBox(mdl,'10 . Osciloscopios en vivo',[30 y1-45 1640 y1+450]);

%% 9 - Horno 3D (Simscape Multibody): puerta que se abre y termometro que sube
x0 = 1720; y2 = 760;
U.addb(mdl,'World Frame','Mundo',[x0+40 y2+60],[40 40]);
U.addb(mdl,'Mechanism Configuration','Config mecanismo',[x0+40 y2+140],[40 40]);
U.addb(mdl,'Solver Configuration','Solver 3D',[x0+40 y2+210],[40 30]);
U.mb(mdl,'Mundo','','Config mecanismo',''); U.mb(mdl,'Mundo','','Solver 3D','');
U.addb(mdl,'Brick Solid','Cuerpo del horno',[x0+180 y2+40],[50 50]);
U.sp(mdl,'Cuerpo del horno','BrickDimensions','[0.4 0.3 0.3]','GraphicDiffuseColor','[0.30 0.31 0.32]');
U.mb(mdl,'Mundo','','Cuerpo del horno','');
rt(U,mdl,'Bisagra (abajo, al frente)',[x0+180 y2+120],'[0 -0.16 -0.15]','+Y','90');
U.mb(mdl,'Mundo','','Bisagra (abajo, al frente)','B');
U.addb(mdl,'Revolute Joint','Puerta (bisagra)',[x0+280 y2+120],[60 60]);
U.sp(mdl,'Puerta (bisagra)','MotionActuationMode','InputMotion','TorqueActuationMode','ComputedTorque');
U.mb(mdl,'Bisagra (abajo, al frente)','F','Puerta (bisagra)','B');
rt(U,mdl,'Centro de la puerta',[x0+380 y2+120],'[-0.15 0 0]','','0');
U.mb(mdl,'Puerta (bisagra)','F','Centro de la puerta','B');
U.addb(mdl,'Brick Solid','Puerta',[x0+470 y2+120],[50 50]);
U.sp(mdl,'Puerta','BrickDimensions','[0.3 0.02 0.4]','GraphicDiffuseColor','[0.62 0.64 0.66]');
U.mb(mdl,'Centro de la puerta','F','Puerta','');
rt(U,mdl,'Pos tubo',[x0+180 y2+220],'[0.27 -0.1 0]','','0');
U.mb(mdl,'Mundo','','Pos tubo','B');
U.addb(mdl,'Cylindrical Solid','Tubo del termometro',[x0+280 y2+220],[50 50]);
U.sp(mdl,'Tubo del termometro','CylinderRadius','0.016','CylinderLength','0.32', ...
    'GraphicDiffuseColor','[0.85 0.90 0.95]','GraphicOpacity','0.35');
U.mb(mdl,'Pos tubo','F','Tubo del termometro','');
rt(U,mdl,'Pos pedestal',[x0+180 y2+300],'[0.27 -0.1 -0.31]','','0');
U.mb(mdl,'Mundo','','Pos pedestal','B');
U.addb(mdl,'Brick Solid','Pedestal',[x0+280 y2+300],[50 50]);
U.sp(mdl,'Pedestal','BrickDimensions','[0.05 0.05 0.3]','GraphicDiffuseColor','[0.2 0.2 0.2]');
U.mb(mdl,'Pos pedestal','F','Pedestal','');
rt(U,mdl,'Pos columna',[x0+180 y2+380],'[0.27 -0.1 -0.48]','','0');
U.mb(mdl,'Mundo','','Pos columna','B');
U.addb(mdl,'Prismatic Joint','Columna (sube con T)',[x0+280 y2+380],[60 60]);
U.sp(mdl,'Columna (sube con T)','MotionActuationMode','InputMotion','TorqueActuationMode','ComputedTorque');
U.mb(mdl,'Pos columna','F','Columna (sube con T)','B');
rt(U,mdl,'Centro columna',[x0+380 y2+380],'[0 0 0.16]','','0');
U.mb(mdl,'Columna (sube con T)','F','Centro columna','B');
U.addb(mdl,'Brick Solid','Liquido rojo',[x0+470 y2+380],[50 50]);
U.sp(mdl,'Liquido rojo','BrickDimensions','[0.012 0.012 0.32]','GraphicDiffuseColor','[0.80 0.15 0.12]');
U.mb(mdl,'Centro columna','F','Liquido rojo','');
% senales que mueven la animacion
U.fro(mdl,'From T 3D','T',[x0+40 y2+470]);
U.addb(mdl,'simulink/Math Operations/Gain','degC a altura',[x0+120 y2+470],[40 30]);
U.sp(mdl,'degC a altura','Gain','0.32/125');
U.addb(mdl,'simulink/Math Operations/Bias','desde 25 degC',[x0+120 y2+520],[40 30]);
U.sp(mdl,'desde 25 degC','Bias','-25*0.32/125');
U.addb(mdl,'simulink/Discontinuities/Saturation','tope del tubo',[x0+190 y2+495],[40 30]);
U.sp(mdl,'tope del tubo','UpperLimit','0.32','LowerLimit','0');
U.addb(mdl,'S-PS','S-PS altura',[x0+250 y2+495],[30 24]);
U.sp(mdl,'S-PS altura','Unit','m','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.05','SimscapeFilterOrder','2');
add_line(mdl,'From T 3D/1','degC a altura/1','autorouting','smart');
add_line(mdl,'degC a altura/1','desde 25 degC/1','autorouting','smart');
add_line(mdl,'desde 25 degC/1','tope del tubo/1','autorouting','smart');
add_line(mdl,'tope del tubo/1','S-PS altura/1','autorouting','smart');
U.W(mdl,{'S-PS altura','RConn',1},{'Columna (sube con T)','LConn',2});
U.fro(mdl,'From Qp 3D','Qp',[x0+40 y2+580]);
U.addb(mdl,'simulink/Math Operations/Gain','W a angulo de puerta',[x0+120 y2+580],[40 30]);
U.sp(mdl,'W a angulo de puerta','Gain','(pi/2)/80');
U.addb(mdl,'S-PS','S-PS puerta 3D',[x0+190 y2+580],[30 24]);
U.sp(mdl,'S-PS puerta 3D','Unit','rad','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.2','SimscapeFilterOrder','2');
add_line(mdl,'From Qp 3D/1','W a angulo de puerta/1','autorouting','smart');
add_line(mdl,'W a angulo de puerta/1','S-PS puerta 3D/1','autorouting','smart');
U.W(mdl,{'S-PS puerta 3D','RConn',1},{'Puerta (bisagra)','LConn',2});
U.areaBox(mdl,'9 . Horno 3D (Simscape Multibody): la puerta se abre y el termometro sube', ...
    [x0-20 y2-50 x0+540 y2+630]);

%% Simulacion: tiempo real (horno pequeno: se calienta en segundos)
set_param(mdl,'StopTime','inf','Solver','ode23t','EnablePacing','on','PacingRate',1, ...
    'SignalLogging','on','ReturnWorkspaceOutputs','on');
U.check(mdl);
carpeta = fileparts(mfilename('fullpath'));
save_system(mdl,fullfile(carpeta,[mdl '.slx']));
fprintf('Practica 2 lista: abre %s.slx y dale Run.\n',mdl);

function rt(U,mdl,name,ctr,tr,eje,ang)
U.addb(mdl,'Rigid Transform',name,ctr,[40 40]);
U.sp(mdl,name,'TranslationMethod','Cartesian','TranslationCartesianOffset',tr);
if ~isempty(eje)
    U.sp(mdl,name,'RotationMethod','StandardAxis','RotationStandardAxis',eje,'RotationAngle',ang);
end
end
