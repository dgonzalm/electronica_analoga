%% practica2_baliza.m - Electronica Analogica (UNAL) - Clase 10
% PRACTICA 2 - Baliza intermitente con un GENERADOR DE ONDA CUADRADA
%   (oscilador de relajacion): comparador con histeresis inversor con Vref = 0
%   (R1 = R2 = 10k, beta = 1/2) + red RC en la entrada (-).
%   R = 100k y C = 4.7 uF  ->  T = 2*R*C*ln(3) = 1.03 s  (f = 0.97 Hz).
%   La salida del AO enciende una lampara del tablero (via transistor).
%   Un medidor calcula el periodo real midiendo el tiempo entre dos flancos.
U = ea_lib();
mdl = 'baliza_oscilador';
if bdIsLoaded(mdl), close_system(mdl,0); end
new_system(mdl);

%% Parametros
P = struct('Vsat',12,'Aol',1e5,'R',100e3,'C',4.7e-6,'R1',10e3,'R2',10e3);
ws = get_param(mdl,'ModelWorkspace');
for f = fieldnames(P)', assignin(ws,f{1},P.(f{1})); end

%% 1 - Oscilador de relajacion (AO1)
U.aoBL(mdl,'AO1',[520 300],'Vsat');
U.placeAt(mdl,'AO1','LConn',2,[480 285]);
% entrada (-): nodo Vc -> capacitor a tierra y R de realimentacion desde la salida
U.Cb(mdl,'C',[400 380],'C','0',true,true);
U.placeTop(mdl,'C',[400 330]);
U.gnd(mdl,'GND C',U.pt(mdl,'C',U.botName(mdl,'C'),1)+[0 20]);
U.W(mdl,{'C',U.topName(mdl,'C'),1},{'AO1','LConn',2});
U.W(mdl,{'C',U.botName(mdl,'C'),1},{'GND C','LConn',1});
U.Rb(mdl,'R',[520 190],'R',false,true);
U.W(mdl,{'AO1','LConn',2},{'R','LConn',1});
U.W(mdl,{'R','RConn',1},{'AO1','RConn',1});
% entrada (+): divisor R1 (a tierra) - R2 (desde la salida): beta = R1/(R1+R2)
U.Rb(mdl,'R1',[440 460],'R1',true);
U.placeTop(mdl,'R1',[440 420]);
U.gnd(mdl,'GND R1',U.pt(mdl,'R1',U.botName(mdl,'R1'),1)+[0 20]);
U.W(mdl,{'R1',U.topName(mdl,'R1'),1},{'AO1','LConn',1});
U.W(mdl,{'R1',U.botName(mdl,'R1'),1},{'GND R1','LConn',1});
U.Rb(mdl,'R2',[560 420],'R2');
U.W(mdl,{'AO1','LConn',1},{'R2','LConn',1});
U.W(mdl,{'R2','RConn',1},{'AO1','RConn',1});
U.addb(mdl,'Solver Configuration','Solver',[330 450],[40 30]);
U.W(mdl,{'Solver','RConn',1},{'GND C','LConn',1});
U.vmeter(mdl,'Vo',{'AO1','RConn',1},'Vo',[700 330]);
U.vmeter(mdl,'Vc',{'AO1','LConn',2},'Vc',[330 230]);
U.area(mdl,'1 . Oscilador de relajacion (AO1): R-C en la entrada (-), R1-R2 en la (+)', ...
   {'AO1','C','GND C','R','R1','GND R1','R2','Solver','Vo','GND Vo','Vo (V)','Goto Vo','Vc','GND Vc','Vc (V)','Goto Vc'});

%% 2 - Baliza (lampara = salida en +Vsat) y medidor de periodo
U.fro(mdl,'From Vo','Vo',[1100 260]);
U.addb(mdl,'simulink/Logic and Bit Operations/Compare To Constant','Baliza encendida?',[1190 260],[60 36]);
U.sp(mdl,'Baliza encendida?','relop','>','const','0');
add_line(mdl,'From Vo/1','Baliza encendida?/1','autorouting','smart');
U.addb(mdl,'simulink/Discrete/Zero-Order Hold','muestreo',[1280 260],[36 30]);
U.sp(mdl,'muestreo','SampleTime','1e-3');
add_line(mdl,'Baliza encendida?/1','muestreo/1','autorouting','smart');
U.addb(mdl,'simulink/Logic and Bit Operations/Detect Increase','flanco de subida',[1360 260],[50 30]);
add_line(mdl,'muestreo/1','flanco de subida/1','autorouting','smart');
U.addb(mdl,'simulink/Signal Attributes/Data Type Conversion','a numero',[1430 260],[40 30]);
U.sp(mdl,'a numero','OutDataTypeStr','double');
add_line(mdl,'flanco de subida/1','a numero/1','autorouting','smart');
U.addb(mdl,'simulink/Sources/Digital Clock','reloj',[1360 340],[40 30]);
U.sp(mdl,'reloj','SampleTime','1e-3');
% ultimo flanco: si hay flanco -> t, si no -> lo que tenia
U.addb(mdl,'simulink/Signal Routing/Switch','guarda t',[1530 340],[40 60]);
U.sp(mdl,'guarda t','Criteria','u2 > Threshold','Threshold','0.5');
U.addb(mdl,'simulink/Discrete/Unit Delay','ultimo flanco',[1530 440],[40 30]);
U.sp(mdl,'ultimo flanco','SampleTime','1e-3','Orientation','left');
add_line(mdl,'reloj/1','guarda t/1','autorouting','smart');
add_line(mdl,'a numero/1','guarda t/2','autorouting','smart');
add_line(mdl,'ultimo flanco/1','guarda t/3','autorouting','smart');
add_line(mdl,'guarda t/1','ultimo flanco/1','autorouting','smart');
% periodo = t - ultimo flanco, solo en el instante del flanco
U.addb(mdl,'simulink/Math Operations/Sum','t - anterior',[1620 300],[25 25]);
U.sp(mdl,'t - anterior','Inputs','+-','IconShape','round');
add_line(mdl,'reloj/1','t - anterior/1','autorouting','smart');
add_line(mdl,'ultimo flanco/1','t - anterior/2','autorouting','smart');
U.addb(mdl,'simulink/Signal Routing/Switch','guarda T',[1700 340],[40 60]);
U.sp(mdl,'guarda T','Criteria','u2 > Threshold','Threshold','0.5');
U.addb(mdl,'simulink/Discrete/Unit Delay','Periodo medido (s)',[1700 440],[40 30]);
U.sp(mdl,'Periodo medido (s)','SampleTime','1e-3','Orientation','left');
add_line(mdl,'t - anterior/1','guarda T/1','autorouting','smart');
add_line(mdl,'a numero/1','guarda T/2','autorouting','smart');
add_line(mdl,'Periodo medido (s)/1','guarda T/3','autorouting','smart');
add_line(mdl,'guarda T/1','Periodo medido (s)/1','autorouting','smart');
U.area(mdl,'2 . Baliza (salida en +Vsat = luz) y medidor de periodo',{'From Vo','Baliza encendida?','muestreo','flanco de subida', ...
   'a numero','reloj','guarda t','ultimo flanco','t - anterior','guarda T','Periodo medido (s)'});

%% 3 - Tablero en vivo
y0 = 640; H = U;
k1 = H.hmi(mdl,'Knob','Perilla: R (ohm)',[60 y0 250 y0+190]);
set_param(k1,'Limits',[20e3 500e3]); H.bindParam(k1,[mdl '/R'],'R');
k2 = H.hmi(mdl,'Knob','Perilla: C (F)',[280 y0 470 y0+190]);
set_param(k2,'Limits',[1e-6 22e-6]); H.bindParam(k2,[mdl '/C'],'c');
l1 = H.hmi(mdl,'Lamp','Baliza',[520 y0+20 640 y0+140]);
H.bindSig(l1,[mdl '/Baliza encendida?']);
set_param(l1,'StateColors',struct('Value',{0,1},'Color',{[0.55 0.45 0.20],[1.00 0.70 0.05]}));
d1 = H.hmi(mdl,'Display','Medidor: periodo (s)',[690 y0+40 900 y0+110]);
H.bindSig(d1,[mdl '/Periodo medido (s)']);
U.areaBox(mdl,'3 . Tablero en vivo - mueve R o C mientras simula',[30 y0-45 960 y0+230]);

%% 4 - Osciloscopio en el lienzo
y1 = y0 + 300;
U.probe(mdl,'s_vo','Vo','1',[60 y1+290],'Vo salida del AO (V)','0.005');
U.probe(mdl,'s_vc','Vc','1',[60 y1+330],'Vc capacitor (V)','0.005');
U.dscope(mdl,'Salida del AO y voltaje del capacitor (V)',[60 y1 900 y1+240],{'s_vo','s_vc'},5,[-14 14]);
U.areaBox(mdl,'4 . Osciloscopio en vivo',[30 y1-45 960 y1+380]);

%% Simulacion en tiempo real
set_param(mdl,'StopTime','inf','Solver','ode23t','MaxStep','0.01','EnablePacing','on','PacingRate',1, ...
    'SignalLogging','on','ReturnWorkspaceOutputs','on');
U.check(mdl);
carpeta = fileparts(mfilename('fullpath'));
save_system(mdl,fullfile(carpeta,[mdl '.slx']));
fprintf('Practica 2 lista: abre %s.slx y dale Run.\n',mdl);
