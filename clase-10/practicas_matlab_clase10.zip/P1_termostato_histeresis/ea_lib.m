function U = ea_lib()
%EA_LIB  Piezas comunes para construir las practicas con AO en Simulink
%   (Electronica Analogica UNAL - Clases 9 y 10). Uso:  U = ea_lib();  U.addb(...)
%   Todas las practicas se arman con estas mismas funciones para que se vean
%   y se lean igual.  Clase 10 agrega: AO con ancho de banda (comparadores),
%   resistencias/capacitores en una linea y voltimetros con Goto.
U.lp        = @lp;          % ruta de un bloque de libreria por su nombre
U.addb      = @addb;        % agrega un bloque centrado en [x y]
U.sp        = @sp;          % set_param con aviso si falla
U.pt        = @pt;          % posicion absoluta de un puerto
U.ph        = @ph;          % handle de un puerto
U.placeAt   = @placeAt;     % mueve un bloque para que un puerto caiga en [x y]
U.placeTop  = @placeTop;
U.topName   = @topName;
U.botName   = @botName;
U.flipAO    = @flipAO;      % AO con (-) arriba y (+) abajo, como en los libros
U.aoPar     = @aoPar;       % AO real: ganancia finita y saturacion +-Vsat
U.gnd       = @gnd;         % tierra electrica con su puerto en [x y]
U.mref      = @mref;        % referencia mecanica
U.W         = @W;           % cable entre dos puertos {bloque,tipo,k}
U.gto       = @gto;         % Goto con su entrada en [x y]
U.fro       = @fro;         % From
U.area      = @area;        % area rotulada alrededor de un grupo de bloques
U.areaBox   = @areaBox;     % area rotulada con caja fija
U.hmi       = @hmi;         % bloque Dashboard
U.bindParam = @bindParam;   % enlaza un control a un parametro
U.bindSig   = @bindSig;     % enlaza un indicador a una senal
U.probe     = @probe;       % sonda (From -> ganancia -> terminador) registrada
U.dscope    = @dscope;      % osciloscopio en el lienzo (Dashboard Scope)
U.check     = @check;       % lista puertos sueltos
U.mb        = @mb;          % enlace de marcos Multibody
U.ctrl      = @ctrl;        % controlador PI / PD / PID con 2 AO (compacto + inversor)
U.refsrc    = @refsrc;      % referencia: constante (perilla) -> volts -> fuente
U.senscvs   = @senscvs;     % fuente del sensor conectada invertida (-Vsensor)
U.aoBL      = @aoBL;        % AO real con ancho de banda y slew rate (Clase 10: comparadores)
U.Rb        = @Rb;          % resistencia con valor (y opcion de perilla en vivo)
U.Cb        = @Cb;          % capacitor con valor y voltaje inicial
U.vmeter    = @vmeter;      % voltimetro a tierra -> PS-Simulink -> Goto
U.psrc      = @psrc;        % senal Simulink -> fuente de voltaje controlada a tierra
end

%% ------------------------------------------------------------------ rutas
function p = lp(name)
persistent M
if isempty(M)
    M = containers.Map;
    libs = {'fl_lib','ee_lib','sm_lib','nesl_utility'};
    for i = 1:numel(libs)
        load_system(libs{i});
        b = find_system(libs{i},'SearchDepth',3,'Type','Block');
        for j = 1:numel(b)
            n = strrep(get_param(b{j},'Name'),newline,' ');
            if ~isKey(M,n), M(n) = b{j}; end
        end
    end
end
if ~isKey(M,name), error('ea_lib:lp','No encuentro el bloque de libreria "%s"',name); end
p = M(name);
end

%% ------------------------------------------------------------- geometria
function p = addb(mdl,lib,name,ctr,sz,varargin)
if strcmp(lib,'S-PS'), lib = 'nesl_utility/Simulink-PS Converter'; end
if ~contains(lib,'/'), lib = lp(lib); end
p = [mdl '/' name];
add_block(lib,p,'Position',round([ctr-sz/2 ctr+sz/2]),varargin{:});
end
function ok = sp(mdl,name,varargin)
p = [mdl '/' name]; ok = true;
for i = 1:2:numel(varargin)
    try, set_param(p,varargin{i},varargin{i+1});
    catch e, ok = false; fprintf('AVISO %s.%s: %s\n',name,varargin{i},e.message); end
end
end
function q = pt(mdl,name,ty,k)
x = get_param([mdl '/' name],'PortHandles'); q = get_param(x.(ty)(k),'Position');
end
function h = ph(mdl,name,ty,k)
x = get_param([mdl '/' name],'PortHandles'); h = x.(ty)(k);
end
function placeAt(mdl,name,ty,k,xy)
p = [mdl '/' name]; pos = get_param(p,'Position');
d = round(xy - pt(mdl,name,ty,k)); set_param(p,'Position',pos+[d d]);
end
function t = topName(mdl,name)
if pt(mdl,name,'LConn',1)*[0;1] <= pt(mdl,name,'RConn',1)*[0;1], t = 'LConn'; else, t = 'RConn'; end
end
function t = botName(mdl,name)
if strcmp(topName(mdl,name),'LConn'), t = 'RConn'; else, t = 'LConn'; end
end
function placeTop(mdl,name,xy)
placeAt(mdl,name,topName(mdl,name),1,xy);
end
function flipAO(mdl,name)
p = [mdl '/' name]; set_param(p,'BlockRotation',180); set_param(p,'BlockMirror','on');
end
function aoPar(mdl,name)
sp(mdl,name,'A','Aol','Rin','10e6','Rout','1','Vmin','-Vsat','Vmax','Vsat');
end
function gnd(mdl,name,xy)
addb(mdl,'Electrical Reference',name,xy+[0 15],[24 24]);
set_param([mdl '/' name],'ShowName','off'); placeAt(mdl,name,'LConn',1,xy);
end
function mref(mdl,name,xy)
addb(mdl,'Mechanical Rotational Reference',name,xy+[0 15],[24 24]);
set_param([mdl '/' name],'ShowName','off'); placeAt(mdl,name,'LConn',1,xy);
end
function h = W(mdl,a,b)
h = add_line(mdl,ph(mdl,a{:}),ph(mdl,b{:}),'autorouting','smart');
end
function gto(mdl,name,tag,xy)
addb(mdl,'simulink/Signal Routing/Goto',name,xy+[25 0],[50 22]);
set_param([mdl '/' name],'GotoTag',tag,'ShowName','off');
placeAt(mdl,name,'Inport',1,xy);
end
function fro(mdl,name,tag,xy)
addb(mdl,'simulink/Signal Routing/From',name,xy,[50 22]);
set_param([mdl '/' name],'GotoTag',tag,'ShowName','off');
end
function area(mdl,titulo,names,pad)
if nargin < 4, pad = [-20 -40 20 22]; end
bb = [inf inf -inf -inf];
for i = 1:numel(names)
    p = get_param([mdl '/' names{i}],'Position');
    bb = [min(bb(1),p(1)) min(bb(2),p(2)) max(bb(3),p(3)) max(bb(4),p(4))];
end
add_block('built-in/Area',[mdl '/' titulo],'Position',round(bb+pad));
end
function areaBox(mdl,titulo,box)
add_block('built-in/Area',[mdl '/' titulo],'Position',round(box));
end

%% ---------------------------------------------------------- tablero
function b = hmi(mdl,kind,name,pos)
b = [mdl '/' name];
add_block(['simulink_hmi_blocks/' kind],b,'Position',pos);
try, set_param(b,'LabelPosition','Top'); catch, end
try, set_param(b,'ShowInitialText','off'); catch, end
end
function bindParam(b,blk,par)
litval(blk,par);
p = Simulink.HMI.ParamSourceInfo;
p.BlockPath = Simulink.BlockPath(blk);
p.ParamName = par;
set_param(b,'Binding',p);
end
function bindSig(b,blk,port)
if nargin < 3, port = 1; end
s = Simulink.HMI.SignalSpecification;
s.BlockPath = Simulink.BlockPath(blk);
s.OutputPortIndex = port;
set_param(b,'Binding',s);
end
function probe(mdl,name,tag,gain,xy,signame,ts)
if nargin < 7, ts = '0.02'; end
% Sonda: From(tag) -> Ganancia (bloque NO virtual) -> Terminador, registrada.
% El Dashboard Scope solo dibuja senales registradas de bloques no virtuales.
fro(mdl,['From ' name],tag,xy);
addb(mdl,'simulink/Math Operations/Gain',name,xy+[80 0],[40 26]);
set_param([mdl '/' name],'Gain',gain,'ShowName','off','SampleTime',ts);   % todas al mismo ritmo
addb(mdl,'simulink/Sinks/Terminator',['Term ' name],xy+[140 0],[16 16]);
set_param([mdl '/Term ' name],'ShowName','off');
add_line(mdl,['From ' name '/1'],[name '/1']);
add_line(mdl,[name '/1'],['Term ' name '/1']);
o = ph(mdl,name,'Outport',1);
set_param(o,'DataLogging','on','DataLoggingNameMode','Custom','DataLoggingName',signame);
set_param(get_param(o,'Line'),'Name',signame);
end
function b = dscope(mdl,name,pos,probes,span,yl)
b = [mdl '/' name];
add_block('simulink_hmi_blocks/Dashboard Scope',b,'Position',pos);
try, set_param(b,'LabelPosition','Top'); catch, end
s = cell(1,numel(probes));
for i = 1:numel(probes)
    s{i} = Simulink.HMI.SignalSpecification;
    s{i}.BlockPath = Simulink.BlockPath([mdl '/' probes{i}]);
    s{i}.OutputPortIndex = 1;
end
set_param(b,'Binding',s);
set_param(b,'TimeSpan',num2str(span));
if nargin > 5, try, set_param(b,'YLimits',yl); catch, end, end
try, set_param(b,'UpdateMode','Scroll'); catch, end
try, set_param(b,'ShowInitialText','off'); catch, end
end
function nc = check(mdl)
nc = {};
b = find_system(mdl,'SearchDepth',1,'Type','Block');
for i = 2:numel(b)
    p = get_param(b{i},'PortHandles');
    for t = {'LConn','RConn','Inport','Outport'}
        for k = 1:numel(p.(t{1}))
            if get_param(p.(t{1})(k),'Line') == -1
                nc{end+1} = sprintf('%s.%s%d',get_param(b{i},'Name'),t{1},k); %#ok<AGROW>
            end
        end
    end
end
if isempty(nc), fprintf('Conectividad OK (%s): ningun puerto suelto\n',mdl);
else, fprintf('PUERTOS SUELTOS (%s): %s\n',mdl,strjoin(nc,', ')); end
end

%% --------------------------------------------------------- multibody
function mb(mdl,a,sa,b,sb)
% une el marco 'sa' de a con el marco 'sb' de b.  sa/sb: 'B' (base), 'F'
% (seguidor) o '' (bloque con un solo puerto de marco)
add_line(mdl,frame(mdl,a,sa),frame(mdl,b,sb),'autorouting','smart');
end
function h = frame(mdl,name,s)
x = get_param([mdl '/' name],'PortHandles');
switch s
    case 'B', h = x.LConn(1);
    case 'F', h = x.RConn(1);
    otherwise
        if ~isempty(x.RConn), h = x.RConn(1); else, h = x.LConn(1); end
end
end

%% ------------------------------------------- bloques de circuito comunes
function refsrc(mdl,o)
% Referencia: Constante (en unidades fisicas, la mueve la perilla) -> ganancia
% a voltios -> Goto 'Vref' -> Simulink-PS -> fuente de voltaje (area 1).
% o.valor, o.kv (expresion V/unidad), o.nombre (texto de la constante)
addb(mdl,'simulink/Sources/Constant',o.nombre,[70 440],[50 30]);
set_param([mdl '/' o.nombre],'Value',o.valor,'SampleTime','0.01');
addb(mdl,'simulink/Math Operations/Gain','a voltios (ref)',[150 440],[40 30]);
set_param([mdl '/a voltios (ref)'],'Gain',o.kv);
gto(mdl,'Goto Vref','Vref',[200 395]);
addb(mdl,'S-PS','S-PS ref',[215 440],[30 24]);
sp(mdl,'S-PS ref','Unit','V','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.01');
addb(mdl,'Controlled Voltage Source','Fuente Vref',[280 380],[40 60]);
placeAt(mdl,'Fuente Vref','LConn',1,[290 340]);
placeAt(mdl,'S-PS ref','RConn',1,pt(mdl,'Fuente Vref','RConn',1)+[-35 45]);
gnd(mdl,'GND ref',pt(mdl,'Fuente Vref','RConn',2)+[0 32]);
addb(mdl,'Solver Configuration','Solver',[150 300],[40 30]);
placeAt(mdl,'Solver','RConn',1,pt(mdl,'Fuente Vref','LConn',1)+[-60 -30]);
add_line(mdl,[o.nombre '/1'],'a voltios (ref)/1','autorouting','smart');
add_line(mdl,'a voltios (ref)/1','S-PS ref/1','autorouting','smart');
add_line(mdl,'a voltios (ref)/1','Goto Vref/1','autorouting','smart');
W(mdl,{'S-PS ref','RConn',1},{'Fuente Vref','RConn',1});
W(mdl,{'Fuente Vref','RConn',2},{'GND ref','LConn',1});
W(mdl,{'Solver','RConn',1},{'Fuente Vref','LConn',1});
area(mdl,'1 . Referencia',{o.nombre,'a voltios (ref)','Goto Vref','S-PS ref','Fuente Vref','GND ref','Solver'});
end

function ctrl(mdl,o)
% Controlador con 2 AO reales (como en la Clase 8):
%   AO1: sumador inversor compacto  Vo1 = -[Kp(Vref - Vs) + Ki*int(Vref - Vs) - Kd*dVs/dt]
%        Rin1 (Vref) y Rin2 (-Vs) a la entrada (-); R2 (+ C2 si hay I) en realimentacion;
%        rama derivativa Rd + Cd desde -Vs (derivada sobre la medicion: no da "patadas"
%        al mover la referencia).
%   AO2: inversor unitario  ->  u = -Vo1  (esfuerzo de control, satura en +-Vsat)
% o.I, o.D (true/false), o.titulo (texto del area 2)
dx = 60;
addb(mdl,'Finite-Gain Op-Amp','AO1',[520+dx 300],[60 60]); flipAO(mdl,'AO1'); aoPar(mdl,'AO1');
placeAt(mdl,'AO1','LConn',2,[486+dx 285]);
addb(mdl,'Resistor','Rin1',[388 285],[60 20]); sp(mdl,'Rin1','R','Rin');
placeAt(mdl,'Rin1','RConn',1,[420 285]);
addb(mdl,'Resistor','Rin2',[480 370],[20 60],'Orientation','down'); sp(mdl,'Rin2','R','Rin');
placeTop(mdl,'Rin2',[480 335]);
gnd(mdl,'GND AO1',[474+dx 352]);
addb(mdl,'Resistor','R2',[575 220],[60 20]); sp(mdl,'R2','R','R2','R_conf','runtime');
W(mdl,{'Rin1','RConn',1},{'AO1','LConn',2});
W(mdl,{'Rin2',topName(mdl,'Rin2'),1},{'AO1','LConn',2});
W(mdl,{'AO1','LConn',1},{'GND AO1','LConn',1});
W(mdl,{'AO1','LConn',2},{'R2','LConn',1});
miembros = {'AO1','Rin1','Rin2','GND AO1','R2'};
if o.I
    addb(mdl,'Capacitor','C2',[660 220],[60 20]); sp(mdl,'C2','c','C2');
    W(mdl,{'R2','RConn',1},{'C2','LConn',1});
    W(mdl,{'C2','RConn',1},{'AO1','RConn',1});
    miembros{end+1} = 'C2';
else
    W(mdl,{'R2','RConn',1},{'AO1','RConn',1});
end
if o.D
    addb(mdl,'Capacitor','Cd',[445 365],[20 60],'Orientation','down'); sp(mdl,'Cd','c','Cd','c_conf','runtime');
    placeTop(mdl,'Cd',[445 335]);
    addb(mdl,'Resistor','Rd',[445 440],[20 60],'Orientation','down'); sp(mdl,'Rd','R','Rd');
    placeTop(mdl,'Rd',pt(mdl,'Cd',botName(mdl,'Cd'),1)+[0 15]);
    W(mdl,{'Cd',topName(mdl,'Cd'),1},{'AO1','LConn',2});
    W(mdl,{'Cd',botName(mdl,'Cd'),1},{'Rd',topName(mdl,'Rd'),1});
    W(mdl,{'Rd',botName(mdl,'Rd'),1},{'Rin2',botName(mdl,'Rin2'),1});
    miembros = [miembros {'Cd','Rd'}];
end
area(mdl,['2 . ' o.titulo ' (AO1)'],miembros);
% AO2 inversor
addb(mdl,'Finite-Gain Op-Amp','AO2',[800+dx 315],[60 60]); flipAO(mdl,'AO2'); aoPar(mdl,'AO2');
placeAt(mdl,'AO2','LConn',2,[766+dx 300]);
addb(mdl,'Resistor','R3',[700+dx 300],[60 20]); sp(mdl,'R3','R','Rinv');
placeAt(mdl,'R3','RConn',1,[736+dx 300]);
addb(mdl,'Resistor','R4',[800+dx 235],[60 20]); sp(mdl,'R4','R','Rinv');
gnd(mdl,'GND AO2',[754+dx 367]);
W(mdl,{'AO1','RConn',1},{'R3','LConn',1});
W(mdl,{'R3','RConn',1},{'AO2','LConn',2});
W(mdl,{'AO2','LConn',2},{'R4','LConn',1});
W(mdl,{'R4','RConn',1},{'AO2','RConn',1});
W(mdl,{'AO2','LConn',1},{'GND AO2','LConn',1});
W(mdl,{'Fuente Vref','LConn',1},{'Rin1','LConn',1});
area(mdl,'3 . Inversor (AO2): esfuerzo de control u',{'AO2','R3','R4','GND AO2'});
% voltimetro del esfuerzo de control u (salida de AO2) -> Goto 'u'
addb(mdl,'Voltage Sensor','Voltimetro u',[960 420],[30 50],'Orientation','down');
placeTop(mdl,'Voltimetro u',[960 385]);
gnd(mdl,'GND u',pt(mdl,'Voltimetro u','RConn',2)+[0 30]);
W(mdl,{'Voltimetro u','LConn',1},{'AO2','RConn',1});
W(mdl,{'Voltimetro u','RConn',2},{'GND u','LConn',1});
addb(mdl,'PS-Simulink Converter','u (V)',[1010 520],[36 24]); sp(mdl,'u (V)','Unit','V');
W(mdl,{'Voltimetro u','RConn',1},{'u (V)','LConn',1});
gto(mdl,'Goto u','u',pt(mdl,'u (V)','Outport',1)+[30 0]);
add_line(mdl,ph(mdl,'u (V)','Outport',1),ph(mdl,'Goto u','Inport',1));
end

function senscvs(mdl,xy)
% Fuente controlada que convierte la senal del sensor (PS, en voltios) en un
% voltaje del circuito, conectada INVERTIDA: (+) a tierra, (-) entrega -Vsensor
% hacia Rin2 (y hacia la rama derivativa si existe). xy = posicion de (-).
addb(mdl,'Controlled Voltage Source','Sensor (invertido)',xy-[0 40],[40 60]);
placeAt(mdl,'Sensor (invertido)','RConn',2,xy);
gnd(mdl,'GND sensor',pt(mdl,'Sensor (invertido)','LConn',1)+[50 45]);
W(mdl,{'Sensor (invertido)','LConn',1},{'GND sensor','LConn',1});
W(mdl,{'Sensor (invertido)','RConn',2},{'Rin2',botName(mdl,'Rin2'),1});
end
function litval(blk,par)
% el tablero solo se enlaza a valores literales: si el parametro es una variable, se reemplaza por su valor
v = get_param(blk,par);
if ~isnan(str2double(v)), return, end
try, x = getVariable(get_param(bdroot(blk),'ModelWorkspace'),v); catch, x = evalin('base',v); end
set_param(blk,par,num2str(x,'%.6g'));
end

%% ------------------------------------------------ piezas nuevas (Clase 10)
function aoBL(mdl,name,ctr,V0)
% AO real con ganancia 1e5, GBW = 1 MHz (polo en 10 Hz), slew rate 1 V/us y
% salida limitada a +-Vsat.  Al tener dinamica propia, la realimentacion
% POSITIVA (comparador con histeresis) conmuta limpio, como en el laboratorio.
% Puertos: LConn1 = (+), LConn2 = (-), RConn1 = salida.  Con flipAO la (-) queda arriba.
if nargin < 4, V0 = '0'; end
addb(mdl,'Band-Limited Op-Amp',name,ctr,[60 60]); flipAO(mdl,name);
sp(mdl,name,'A','Aol','Rin','10e6','Rout','10','Vmin','-Vsat','Vmax','Vsat', ...
    'Vdotmax','1e6','f','10','V0',V0);
end
function Rb(mdl,name,ctr,val,vert,live)
if nargin < 5, vert = false; end
if nargin < 6, live = false; end
if vert, addb(mdl,'Resistor',name,ctr,[20 60],'Orientation','down');
else,    addb(mdl,'Resistor',name,ctr,[60 20]); end
sp(mdl,name,'R',val);
if live, sp(mdl,name,'R_conf','runtime'); end
end
function Cb(mdl,name,ctr,val,v0,vert,live)
if nargin < 6, vert = true; end
if nargin < 7, live = false; end
if vert, addb(mdl,'Capacitor',name,ctr,[20 60],'Orientation','down');
else,    addb(mdl,'Capacitor',name,ctr,[60 20]); end
sp(mdl,name,'c',val);
if ~isempty(v0), sp(mdl,name,'vc_specify','on','vc_priority','High','vc',v0); end
if live, sp(mdl,name,'c_conf','runtime'); end
end
function vmeter(mdl,name,node,tag,xy)
% voltimetro entre {bloque,puerto,k} y tierra; su lectura va a un Goto 'tag'
addb(mdl,'Voltage Sensor',name,xy,[30 50],'Orientation','down');
gnd(mdl,['GND ' name],pt(mdl,name,'RConn',2)+[0 25]);
W(mdl,node,{name,'LConn',1});
W(mdl,{name,'RConn',2},{['GND ' name],'LConn',1});
addb(mdl,'PS-Simulink Converter',[name ' (V)'],xy+[60 40],[36 24]); sp(mdl,[name ' (V)'],'Unit','V');
W(mdl,{name,'RConn',1},{[name ' (V)'],'LConn',1});
gto(mdl,['Goto ' tag],tag,pt(mdl,[name ' (V)'],'Outport',1)+[25 0]);
add_line(mdl,ph(mdl,[name ' (V)'],'Outport',1),ph(mdl,['Goto ' tag],'Inport',1));
end
function psrc(mdl,name,xy,inblk,tau)
% senal de Simulink (bloque inblk) -> S-PS -> fuente controlada (+ arriba, - a tierra)
if nargin < 5, tau = '1e-4'; end
addb(mdl,'Controlled Voltage Source',name,xy,[40 60]);
addb(mdl,'S-PS',['S-PS ' name],pt(mdl,name,'RConn',1)+[-45 0],[30 24]);
placeAt(mdl,['S-PS ' name],'RConn',1,pt(mdl,name,'RConn',1)+[-35 0]);
sp(mdl,['S-PS ' name],'Unit','V','FilteringAndDerivatives','filter','InputFilterTimeConstant',tau);
gnd(mdl,['GND ' name],pt(mdl,name,'RConn',2)+[0 25]);
W(mdl,{['S-PS ' name],'RConn',1},{name,'RConn',1});
W(mdl,{name,'RConn',2},{['GND ' name],'LConn',1});
add_line(mdl,[inblk '/1'],['S-PS ' name '/1'],'autorouting','smart');
end
