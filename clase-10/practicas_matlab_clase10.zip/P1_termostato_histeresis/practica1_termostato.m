%% practica1_termostato.m - Electronica Analogica (UNAL) - Clase 10
% PRACTICA 1 - Termostato ON/OFF con COMPARADOR CON HISTERESIS (Schmitt inversor)
%   Una incubadora de laboratorio con un calefactor de 40 W y un transmisor de
%   temperatura de 0.1 V/degC. El AO1 enciende el calefactor a 38 degC y lo apaga
%   a 42 degC (R = 10k, nR = 590k, Vref = 4.07 V).  El AO2 es un comparador
%   SIMPLE (un solo umbral, 4.0 V) para comparar: con el interruptor del tablero
%   eliges cual de los dos manda el calefactor y cuentas las conmutaciones del rele.
U = ea_lib();
mdl = 'termostato_histeresis';
if bdIsLoaded(mdl), close_system(mdl,0); end
new_system(mdl);

%% Parametros (Model Workspace)
P = struct('Vsat',12,'Aol',1e5, ...
  'R',10e3,'nR',590e3,'Vref',4.07, ...  % umbrales 3.8 V y 4.2 V  (38 y 42 degC)
  'Ktr',0.1,'Pcal',40,'Tamb',25, ...    % transmisor 0.1 V/degC, calefactor 40 W
  'Mi',0.02,'ci',500,'kamb',1);         % incubadora: 10 J/K y 1 W/K de perdidas
ws = get_param(mdl,'ModelWorkspace');
for f = fieldnames(P)', assignin(ws,f{1},P.(f{1})); end

%% 1 - Sensor: temperatura -> 0.1 V/degC + ruido -> fuente Vin
U.fro(mdl,'From T sensor','T',[60 200]);
U.addb(mdl,'simulink/Math Operations/Gain','Transmisor (0.1 V por degC)',[140 200],[40 30]);
U.sp(mdl,'Transmisor (0.1 V por degC)','Gain','Ktr');
U.addb(mdl,'simulink/Sources/Band-Limited White Noise','Ruido',[60 270],[40 30]);
U.sp(mdl,'Ruido','Cov','0.01','Ts','0.01','seed','23341');
U.addb(mdl,'simulink/Math Operations/Gain','Ruido (V rms)',[140 270],[40 30]);
U.sp(mdl,'Ruido (V rms)','Gain','0.03');
U.addb(mdl,'simulink/Math Operations/Sum','Sensor + ruido',[220 230],[25 25]);
U.sp(mdl,'Sensor + ruido','Inputs','++','IconShape','round');
add_line(mdl,'From T sensor/1','Transmisor (0.1 V por degC)/1','autorouting','smart');
add_line(mdl,'Ruido/1','Ruido (V rms)/1','autorouting','smart');
add_line(mdl,'Transmisor (0.1 V por degC)/1','Sensor + ruido/1','autorouting','smart');
add_line(mdl,'Ruido (V rms)/1','Sensor + ruido/2','autorouting','smart');
U.gto(mdl,'Goto Vin','Vin',[260 300]);
add_line(mdl,'Sensor + ruido/1','Goto Vin/1','autorouting','smart');
U.psrc(mdl,'Sensor Vin',[330 230],'Sensor + ruido','5e-3');
U.addb(mdl,'Solver Configuration','Solver',[300 120],[40 30]);
U.W(mdl,{'Solver','RConn',1},{'Sensor Vin','LConn',1});
U.area(mdl,'1 . Sensor de temperatura (0.1 V por degC) con ruido',{'From T sensor','Transmisor (0.1 V por degC)', ...
   'Ruido','Ruido (V rms)','Sensor + ruido','Goto Vin','S-PS Sensor Vin','Sensor Vin','GND Sensor Vin','Solver'});

%% 2 - Referencia Vref (perilla)
U.addb(mdl,'simulink/Sources/Constant','Vref (V)',[60 470],[50 30]);
U.sp(mdl,'Vref (V)','Value','Vref','SampleTime','0.01');
U.psrc(mdl,'Fuente Vref',[330 470],'Vref (V)','0.01');
U.area(mdl,'2 . Referencia',{'Vref (V)','S-PS Fuente Vref','Fuente Vref','GND Fuente Vref'});

%% 3 - Comparador con histeresis (AO1): Vin a (-), Vref por R a (+), nR de la salida a (+)
U.aoBL(mdl,'AO1',[620 300],'Vsat');
U.placeAt(mdl,'AO1','LConn',2,[580 285]);
U.W(mdl,{'Sensor Vin','LConn',1},{'AO1','LConn',2});
U.Rb(mdl,'R',[500 420],'R');
U.W(mdl,{'Fuente Vref','LConn',1},{'R','LConn',1});
U.W(mdl,{'R','RConn',1},{'AO1','LConn',1});
U.Rb(mdl,'nR',[620 400],'nR',false,true);
U.W(mdl,{'R','RConn',1},{'nR','LConn',1});
U.W(mdl,{'nR','RConn',1},{'AO1','RConn',1});
U.vmeter(mdl,'Vo histeresis',{'AO1','RConn',1},'Vo_h',[760 330]);
U.area(mdl,'3 . Comparador con histeresis (AO1)',{'AO1','R','nR','Vo histeresis','GND Vo histeresis','Vo histeresis (V)','Goto Vo_h'});

%% 4 - Comparador simple (AO2) para comparar: un solo umbral = centro de la banda
U.addb(mdl,'simulink/Math Operations/Gain','centro de la banda',[140 730],[40 30]);
U.sp(mdl,'centro de la banda','Gain','nR/(R+nR)');
add_line(mdl,'Vref (V)/1','centro de la banda/1','autorouting','smart');
U.psrc(mdl,'Umbral unico',[330 750],'centro de la banda','0.01');
U.aoBL(mdl,'AO2',[620 730],'Vsat');
U.W(mdl,{'Sensor Vin','LConn',1},{'AO2','LConn',2});
U.W(mdl,{'Umbral unico','LConn',1},{'AO2','LConn',1});
U.vmeter(mdl,'Vo simple',{'AO2','RConn',1},'Vo_s',[760 770]);
U.area(mdl,'4 . Comparador simple, sin histeresis (AO2)',{'centro de la banda','S-PS Umbral unico','Umbral unico', ...
   'GND Umbral unico','AO2','Vo simple','GND Vo simple','Vo simple (V)','Goto Vo_s'});

%% 5 - Selector y calefactor: Vo > 0  ->  calefactor encendido
U.fro(mdl,'From Vo_h','Vo_h',[1070 260]);
U.fro(mdl,'From Vo_s','Vo_s',[1070 340]);
U.addb(mdl,'simulink/Sources/Constant','Usar histeresis (1 = si)',[1070 300],[50 26]);
U.sp(mdl,'Usar histeresis (1 = si)','Value','1','SampleTime','0.01');
U.addb(mdl,'simulink/Signal Routing/Switch','Selector',[1160 300],[40 60]);
U.sp(mdl,'Selector','Criteria','u2 >= Threshold','Threshold','0.5');
add_line(mdl,'From Vo_h/1','Selector/1','autorouting','smart');
add_line(mdl,'Usar histeresis (1 = si)/1','Selector/2','autorouting','smart');
add_line(mdl,'From Vo_s/1','Selector/3','autorouting','smart');
U.addb(mdl,'simulink/Logic and Bit Operations/Compare To Constant','Calefactor encendido?',[1250 300],[60 36]);
U.sp(mdl,'Calefactor encendido?','relop','>','const','0');
add_line(mdl,'Selector/1','Calefactor encendido?/1','autorouting','smart');
U.addb(mdl,'simulink/Math Operations/Gain','Potencia (W)',[1340 300],[40 30]);
U.sp(mdl,'Potencia (W)','Gain','Pcal');
U.addb(mdl,'simulink/Signal Attributes/Data Type Conversion','encendido (0 o 1)',[1295 340],[40 26]);
U.sp(mdl,'encendido (0 o 1)','OutDataTypeStr','double','ShowName','off');
add_line(mdl,'Calefactor encendido?/1','encendido (0 o 1)/1','autorouting','smart');
add_line(mdl,'encendido (0 o 1)/1','Potencia (W)/1','autorouting','smart');
U.gto(mdl,'Goto P','P',[1390 260]);
add_line(mdl,'Potencia (W)/1','Goto P/1','autorouting','smart');
% contador de conmutaciones del rele
U.addb(mdl,'simulink/Discrete/Zero-Order Hold','muestreo',[1250 400],[36 30]);
U.sp(mdl,'muestreo','SampleTime','1e-3');
add_line(mdl,'Calefactor encendido?/1','muestreo/1','autorouting','smart');
U.addb(mdl,'simulink/Logic and Bit Operations/Detect Change','cambio?',[1320 400],[50 30]);
add_line(mdl,'muestreo/1','cambio?/1','autorouting','smart');
U.addb(mdl,'simulink/Signal Attributes/Data Type Conversion','a numero',[1390 400],[40 30]);
U.sp(mdl,'a numero','OutDataTypeStr','double');
add_line(mdl,'cambio?/1','a numero/1','autorouting','smart');
U.addb(mdl,'simulink/Math Operations/Sum','acumula',[1460 400],[25 25]);
U.sp(mdl,'acumula','Inputs','++','IconShape','round');
U.addb(mdl,'simulink/Discrete/Unit Delay','Conmutaciones del rele',[1460 470],[40 30]);
U.sp(mdl,'Conmutaciones del rele','SampleTime','1e-3','Orientation','left');
add_line(mdl,'a numero/1','acumula/1','autorouting','smart');
add_line(mdl,'acumula/1','Conmutaciones del rele/1','autorouting','smart');
add_line(mdl,'Conmutaciones del rele/1','acumula/2','autorouting','smart');
U.area(mdl,'5 . Selector y calefactor (Vo > 0 = encendido) + contador de conmutaciones',{'From Vo_h','From Vo_s', ...
   'Usar histeresis (1 = si)','Selector','Calefactor encendido?','encendido (0 o 1)','Potencia (W)','Goto P','muestreo','cambio?','a numero','acumula','Conmutaciones del rele'});

%% 6 - Planta termica: calefactor -> incubadora -> perdidas al ambiente
U.fro(mdl,'From P','P',[1590 260]);
U.addb(mdl,'S-PS','S-PS calor',[1660 260],[30 24]);
U.sp(mdl,'S-PS calor','Unit','W','FilteringAndDerivatives','filter','InputFilterTimeConstant','0.01');
add_line(mdl,'From P/1','S-PS calor/1','autorouting','smart');
U.addb(mdl,'Controlled Heat Flow Rate Source','Calefactor 40 W',[1750 300],[40 50]);
U.addb(mdl,'Thermal Mass','Incubadora',[1870 220],[50 40]);
U.sp(mdl,'Incubadora','mass','Mi','sp_heat','ci','T_specify','on','T','Tamb','T_unit','degC');
U.addb(mdl,'Conductive Heat Transfer','Perdidas al ambiente',[1970 220],[50 30]);
U.sp(mdl,'Perdidas al ambiente','area','0.01','thickness','0.01','th_cond','kamb');
U.addb(mdl,'Thermal Mass','Ambiente (25 degC)',[2070 200],[50 40]);
U.sp(mdl,'Ambiente (25 degC)','mass','1e6','sp_heat','1000','T_specify','on','T','Tamb','T_unit','degC');
U.addb(mdl,'Thermal Reference','Ref termica',[1750 400],[30 30]);
U.addb(mdl,'Solver Configuration','Solver termico',[1670 400],[40 30]);
U.W(mdl,{'Calefactor 40 W','LConn',1},{'Incubadora','LConn',1});
U.W(mdl,{'Calefactor 40 W','RConn',2},{'Ref termica','LConn',1});
U.W(mdl,{'S-PS calor','RConn',1},{'Calefactor 40 W','RConn',1});
U.W(mdl,{'Incubadora','LConn',1},{'Perdidas al ambiente','LConn',1});
U.W(mdl,{'Perdidas al ambiente','RConn',1},{'Ambiente (25 degC)','LConn',1});
U.W(mdl,{'Solver termico','RConn',1},{'Ref termica','LConn',1});
U.addb(mdl,'Temperature Sensor','Termometro',[1870 340],[40 40]);
U.W(mdl,{'Incubadora','LConn',1},{'Termometro','LConn',1});
U.addb(mdl,'Thermal Reference','Ref termica 2',[1930 420],[30 30]);
U.addb(mdl,'PS-Simulink Converter','T (degC)',[1990 340],[36 24]);
U.sp(mdl,'T (degC)','Unit','degC','AffineConversion','on');
try
    U.W(mdl,{'Termometro','RConn',1},{'T (degC)','LConn',1});
    U.W(mdl,{'Termometro','RConn',2},{'Ref termica 2','LConn',1});
catch
    U.W(mdl,{'Termometro','RConn',2},{'T (degC)','LConn',1});
    U.W(mdl,{'Termometro','RConn',1},{'Ref termica 2','LConn',1});
end
U.gto(mdl,'Goto T','T',U.pt(mdl,'T (degC)','Outport',1)+[140 0]);
add_line(mdl,U.ph(mdl,'T (degC)','Outport',1),U.ph(mdl,'Goto T','Inport',1),'autorouting','smart');
U.area(mdl,'6 . Incubadora (planta termica)',{'From P','S-PS calor','Calefactor 40 W','Incubadora','Perdidas al ambiente', ...
   'Ambiente (25 degC)','Ref termica','Solver termico','Termometro','Ref termica 2','T (degC)','Goto T'});

%% 7 - Tablero en vivo
y0 = 930; H = U;
k1 = H.hmi(mdl,'Knob','Perilla: Vref (V)',[60 y0 250 y0+190]);
set_param(k1,'Limits',[3 5]); H.bindParam(k1,[mdl '/Vref (V)'],'Value');
k2 = H.hmi(mdl,'Knob','Perilla: nR (ohm) - ancho de la banda',[280 y0 470 y0+190]);
set_param(k2,'Limits',[100e3 3e6]); H.bindParam(k2,[mdl '/nR'],'R');
s1 = H.hmi(mdl,'Slider','Ruido del sensor (V rms)',[500 y0+50 760 y0+130]);
set_param(s1,'Limits',[0 0.3]); H.bindParam(s1,[mdl '/Ruido (V rms)'],'Gain');
t1 = H.hmi(mdl,'Rocker Switch','Interruptor: arriba con histeresis, abajo sin histeresis',[790 y0+20 990 y0+170]);
H.bindParam(t1,[mdl '/Usar histeresis (1 = si)'],'Value');
g1 = H.hmi(mdl,'Gauge','Temperatura (degC)',[1020 y0 1230 y0+210]);
set_param(g1,'Limits',[20 60]); H.bindSig(g1,[mdl '/T (degC)']);
l1 = H.hmi(mdl,'Lamp','Calefactor',[1260 y0+30 1340 y0+110]);
H.bindSig(l1,[mdl '/Calefactor encendido?']);
set_param(l1,'StateColors',struct('Value',{0,1},'Color',{[0.82 0.82 0.80],[0.90 0.45 0.10]}));
d1 = H.hmi(mdl,'Display','Contador: conmutaciones del rele',[1370 y0+40 1560 y0+110]);
H.bindSig(d1,[mdl '/Conmutaciones del rele']);
U.areaBox(mdl,'7 . Tablero en vivo - mueve las perillas mientras simula',[30 y0-45 1600 y0+250]);

%% 8 - Osciloscopios en el lienzo
y1 = y0 + 320;
U.probe(mdl,'s_T','T','1',[60 y1+290],'Temperatura (degC)','0.01');
U.probe(mdl,'s_vin','Vin','1',[60 y1+330],'Vin del sensor (V)','0.01');
U.probe(mdl,'s_voh','Vo_h','1',[60 y1+370],'Salida con histeresis (V)','0.01');
U.probe(mdl,'s_vos','Vo_s','1',[60 y1+410],'Salida comparador simple (V)','0.01');
U.dscope(mdl,'Temperatura de la incubadora (degC)',[60 y1 560 y1+240],{'s_T'},30,[20 50]);
U.dscope(mdl,'Voltaje del sensor con ruido (V)',[600 y1 1080 y1+240],{'s_vin'},30,[2 5]);
U.dscope(mdl,'Salidas: con histeresis (AO1) y simple (AO2) (V)',[1120 y1 1600 y1+240],{'s_voh','s_vos'},30,[-14 14]);
U.areaBox(mdl,'8 . Osciloscopios en vivo',[30 y1-45 1600 y1+450]);

%% Simulacion en tiempo real
set_param(mdl,'StopTime','inf','Solver','ode23t','MaxStep','0.01','EnablePacing','on','PacingRate',1, ...
    'SignalLogging','on','ReturnWorkspaceOutputs','on');
U.check(mdl);
carpeta = fileparts(mfilename('fullpath'));
save_system(mdl,fullfile(carpeta,[mdl '.slx']));
fprintf('Practica 1 lista: abre %s.slx y dale Run.\n',mdl);
