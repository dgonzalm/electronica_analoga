%% practica4_escalera.m - Electronica Analogica (UNAL) - Clase 10
% PRACTICA 4 - Luz de escalera: TEMPORIZADOR CON AO (retardo al reposo)
%   R1 = R2 = 10k fijan V1 = 6 V en la entrada (+).  El capacitor C = 470 uF se
%   carga por Rt = 91k desde +12 V y entra por la (-).  El pulsador descarga C:
%   mientras Vc < V1 la salida esta en +Vsat (luz encendida); cuando Vc pasa
%   V1, la salida cae a -Vsat (luz apagada).  t = 0.693*Rt*C = 29.6 s.
%   Un cronometro mide cuanto tiempo estuvo encendida la luz.
U = ea_lib();
mdl = 'luz_escalera';
if bdIsLoaded(mdl), close_system(mdl,0); end
new_system(mdl);

%% Parametros
P = struct('Vsat',12,'Aol',1e5,'V',12,'R1',10e3,'R2',10e3,'Rt',91e3,'C',470e-6);
ws = get_param(mdl,'ModelWorkspace');
for f = fieldnames(P)', assignin(ws,f{1},P.(f{1})); end

%% 1 - Fuente de 12 V y divisor de referencia R1-R2 -> V1 a la entrada (+)
U.addb(mdl,'DC Voltage Source','Fuente 12 V',[120 330],[40 60]);
U.sp(mdl,'Fuente 12 V','v0','V');
U.gnd(mdl,'GND fuente',U.pt(mdl,'Fuente 12 V','RConn',1)+[0 25]);
U.W(mdl,{'Fuente 12 V','RConn',1},{'GND fuente','LConn',1});
U.addb(mdl,'Solver Configuration','Solver',[60 420],[40 30]);
U.W(mdl,{'Solver','RConn',1},{'GND fuente','LConn',1});
U.Rb(mdl,'R1',[260 220],'R1',true);
U.Rb(mdl,'R2',[260 340],'R2',true);
U.gnd(mdl,'GND R2',U.pt(mdl,'R2',U.botName(mdl,'R2'),1)+[0 20]);
U.W(mdl,{'Fuente 12 V','LConn',1},{'R1',U.topName(mdl,'R1'),1});
U.W(mdl,{'R1',U.botName(mdl,'R1'),1},{'R2',U.topName(mdl,'R2'),1});
U.W(mdl,{'R2',U.botName(mdl,'R2'),1},{'GND R2','LConn',1});


%% 2 - Red de tiempo: Rt desde +12 V, C a tierra y pulsador en paralelo con C
U.Rb(mdl,'Rt',[420 440],'Rt',false,true);
U.W(mdl,{'Fuente 12 V','LConn',1},{'Rt','LConn',1});
U.Cb(mdl,'C',[520 520],'C','V',true);
U.placeTop(mdl,'C',U.pt(mdl,'Rt','RConn',1)+[40 40]);
U.gnd(mdl,'GND C',U.pt(mdl,'C',U.botName(mdl,'C'),1)+[0 20]);
U.W(mdl,{'Rt','RConn',1},{'C',U.topName(mdl,'C'),1});
U.W(mdl,{'C',U.botName(mdl,'C'),1},{'GND C','LConn',1});
% pulsador = interruptor controlado (se cierra mientras el boton esta oprimido)
U.addb(mdl,'Switch','Pulsador (NA)',[620 520],[40 60]);
U.sp(mdl,'Pulsador (NA)','R_closed','1','G_open','1e-9','Threshold','0.5');
U.W(mdl,{'C',U.topName(mdl,'C'),1},{'Pulsador (NA)','LConn',1});
U.gnd(mdl,'GND pulsador',U.pt(mdl,'Pulsador (NA)','RConn',2)+[0 20]);
U.W(mdl,{'Pulsador (NA)','RConn',2},{'GND pulsador','LConn',1});
U.addb(mdl,'simulink/Sources/Constant','Boton (1 = oprimido)',[540 640],[50 30]);
U.sp(mdl,'Boton (1 = oprimido)','Value','0','SampleTime','0.01');
U.addb(mdl,'S-PS','S-PS boton',[620 640],[30 24]);
add_line(mdl,'Boton (1 = oprimido)/1','S-PS boton/1','autorouting','smart');
U.W(mdl,{'S-PS boton','RConn',1},{'Pulsador (NA)','RConn',1});


%% 3 - Comparador (AO1): V1 a la (+), Vc a la (-)
U.aoBL(mdl,'AO1',[900 300],'-Vsat');
U.W(mdl,{'R1',U.botName(mdl,'R1'),1},{'AO1','LConn',1});
U.W(mdl,{'C',U.topName(mdl,'C'),1},{'AO1','LConn',2});
U.vmeter(mdl,'Vo',{'AO1','RConn',1},'Vo',[1020 330]);
U.vmeter(mdl,'Vc',{'C',U.topName(mdl,'C'),1},'Vc',[720 520]);
U.vmeter(mdl,'V1',{'R1',U.botName(mdl,'R1'),1},'V1',[190 80]);
U.area(mdl,'3 . Comparador (AO1): luz encendida mientras Vc < V1',{'AO1','Vo','GND Vo','Vo (V)','Goto Vo'});

U.area(mdl,'1 . Fuente de 12 V y referencia V1 (divisor R1-R2)',{'Fuente 12 V','GND fuente','Solver','R1','R2','GND R2','V1','GND V1','V1 (V)','Goto V1'});
U.area(mdl,'2 . Red de tiempo Rt-C y pulsador',{'Rt','C','GND C','Pulsador (NA)','GND pulsador','Boton (1 = oprimido)','S-PS boton','Vc','GND Vc','Vc (V)','Goto Vc'});

%% 4 - Luz y cronometro
U.fro(mdl,'From Vo','Vo',[1260 260]);
U.addb(mdl,'simulink/Logic and Bit Operations/Compare To Constant','Luz encendida?',[1340 260],[60 36]);
U.sp(mdl,'Luz encendida?','relop','>','const','0');
add_line(mdl,'From Vo/1','Luz encendida?/1','autorouting','smart');
U.addb(mdl,'simulink/Signal Attributes/Data Type Conversion','luz (0 o 1)',[1420 260],[40 26]);
U.sp(mdl,'luz (0 o 1)','OutDataTypeStr','double');
add_line(mdl,'Luz encendida?/1','luz (0 o 1)/1','autorouting','smart');
U.addb(mdl,'simulink/Continuous/Integrator','Tiempo encendida (s)',[1520 260],[40 30]);
U.sp(mdl,'Tiempo encendida (s)','ExternalReset','rising');
add_line(mdl,'luz (0 o 1)/1','Tiempo encendida (s)/1','autorouting','smart');
add_line(mdl,'Boton (1 = oprimido)/1','Tiempo encendida (s)/2','autorouting','smart');
U.area(mdl,'4 . Luz de la escalera y cronometro (se reinicia al oprimir el boton)',{'From Vo','Luz encendida?','luz (0 o 1)','Tiempo encendida (s)'});

%% 5 - Tablero en vivo
y0 = 800; H = U;
b1 = H.hmi(mdl,'Push Button','Pulsador de la escalera',[60 y0+40 240 y0+130]);
H.bindParam(b1,[mdl '/Boton (1 = oprimido)'],'Value');
try, set_param(b1,'ButtonText','OPRIMIR'); catch, end
try, set_param(b1,'OnValue','1'); catch, end
k1 = H.hmi(mdl,'Knob','Perilla: Rt (ohm)',[280 y0 470 y0+190]);
set_param(k1,'Limits',[10e3 200e3]); H.bindParam(k1,[mdl '/Rt'],'R');
l1 = H.hmi(mdl,'Lamp','Luz de la escalera',[520 y0+20 640 y0+140]);
H.bindSig(l1,[mdl '/Luz encendida?']);
set_param(l1,'StateColors',struct('Value',{0,1},'Color',{[0.45 0.45 0.42],[1.00 0.85 0.30]}));
d1 = H.hmi(mdl,'Display','Cronometro: tiempo encendida (s)',[690 y0+40 930 y0+110]);
H.bindSig(d1,[mdl '/Tiempo encendida (s)']);
U.areaBox(mdl,'5 . Tablero en vivo - oprime el pulsador y mira cuanto dura la luz',[30 y0-45 980 y0+230]);

%% 6 - Osciloscopio en el lienzo
y1 = y0 + 300;
U.probe(mdl,'s_vc','Vc','1',[60 y1+290],'Vc capacitor (V)','0.05');
U.probe(mdl,'s_v1','V1','1',[60 y1+330],'V1 referencia (V)','0.05');
U.probe(mdl,'s_vo','Vo','1',[60 y1+370],'Vo salida del AO (V)','0.05');
U.dscope(mdl,'Capacitor Vc contra la referencia V1 (V)',[60 y1 520 y1+240],{'s_vc','s_v1'},60,[-1 13]);
U.dscope(mdl,'Salida del AO (V)',[560 y1 960 y1+240],{'s_vo'},60,[-14 14]);
U.areaBox(mdl,'6 . Osciloscopios en vivo',[30 y1-45 980 y1+420]);

%% Simulacion en tiempo real
set_param(mdl,'StopTime','inf','Solver','ode23t','MaxStep','0.01','EnablePacing','on','PacingRate',1, ...
    'SignalLogging','on','ReturnWorkspaceOutputs','on');
U.check(mdl);
carpeta = fileparts(mfilename('fullpath'));
save_system(mdl,fullfile(carpeta,[mdl '.slx']));
fprintf('Practica 4 lista: abre %s.slx y dale Run.\n',mdl);
