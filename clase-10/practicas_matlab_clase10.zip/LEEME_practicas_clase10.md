# Clase 10 – Prácticas en Simulink: histéresis, generadores de onda y temporizador con AO

Cada práctica está en su propia carpeta y no depende de las demás. Cada carpeta tiene el script, `ea_lib.m` y el modelo `.slx`:

```
MATLAB/
├── P1_termostato_histeresis/     practica1_termostato.m   → termostato_histeresis.slx
├── P2_baliza_oscilador/          practica2_baliza.m       → baliza_oscilador.slx
├── P3_generador_funciones_pwm/   practica3_generador.m    → generador_funciones_pwm.slx
└── P4_luz_escalera/              practica4_escalera.m     → luz_escalera.slx
```

Abra MATLAB **dentro de la carpeta de la práctica** y abra el `.slx` directamente, o ejecute el script para regenerarlo (útil si su versión de MATLAB es anterior a R2026b, con la que se guardaron los `.slx`). Luego dele **Run** y mueva el tablero mientras simula.
Se necesitan: Simulink, Simscape y Simscape Electrical (no hace falta Multibody).

| Script | Modelo | Circuito con AO | Qué se mueve en el tablero |
|---|---|---|---|
| `practica1_termostato.m` | `termostato_histeresis.slx` | Comparador con histéresis **inversor** (R = 10 kΩ, nR = 590 kΩ, Vref = 4.07 V) + un comparador simple para comparar | Vref, nR (ancho de la banda), ruido del sensor, interruptor con/sin histéresis |
| `practica2_baliza.m` | `baliza_oscilador.slx` | **Generador de onda cuadrada** (oscilador de relajación): R = 100 kΩ, C = 4.7 µF, R1 = R2 = 10 kΩ | R y C; lámpara y medidor de período |
| `practica3_generador.m` | `generador_funciones_pwm.slx` | **Integrador + Schmitt no inversor** (75 kΩ, 10 nF, 10 kΩ/30 kΩ) y un tercer AO que genera **PWM** | R del integrador (frecuencia), nR (amplitud), Vc (ciclo útil) |
| `practica4_escalera.m` | `luz_escalera.slx` | **Temporizador** (retardo al reposo): R1 = R2 = 10 kΩ, Rt = 91 kΩ, C = 470 µF | Pulsador, Rt; lámpara y cronómetro |

`ea_lib.m` es la librería común (la misma de la Clase 9, con funciones nuevas para comparadores, resistencias, capacitores y voltímetros). Hay una copia idéntica en cada carpeta para que cada práctica funcione sola.

## Los AO de estas prácticas son "reales"
Los cuatro modelos usan el bloque **Band-Limited Op-Amp** de Simscape Electrical, con estos valores:
- ganancia de 10⁵,
- producto ganancia–ancho de banda de 1 MHz,
- slew rate de 1 V/µs,
- salida limitada a ±12 V.

Con un AO ideal sin dinámica, la realimentación positiva del comparador con histéresis no tiene cómo "decidir" hacia dónde saltar. Con un AO real conmuta limpio, como en el laboratorio.

## Verificado en simulación (MATLAB R2026b)

| Práctica | Calculado en clase | Simulado |
|---|---|---|
| P1 Termostato | Umbrales en 38 °C y 42 °C | Con el ruido por defecto (0.03 V rms), la temperatura queda entre 38.1 y 41.7 °C y el relé conmuta 20 veces en 40 s. Sin histéresis conmuta 1 420 veces en 40 s. |
| P2 Baliza | T = 2.2·RC = 1.03 s; Vc entre ±6 V | T = 1.03 s; Vc entre −5.97 y +5.97 V |
| P3 Generador | f = n/(4RC) = 1 kHz; triangular ±4 V; D = 75 % con Vc = 2 V | Período de 1.05 ms (≈ 950 Hz); triangular de ±4.12 V; D = 74.5 % |
| P4 Luz de escalera | t = 0.693·Rt·C = 29.6 s | La luz se apaga a los 29.6 s; Vc(10 s) = 2.51 V, Vc(20 s) = 4.49 V |

En P3 la diferencia con la fórmula es real: el slew rate del AO tarda ≈ 24 µs en cada cambio de la cuadrada (de −12 V a +12 V a 1 V/µs). Mientras tanto, la triangular se pasa un poco del umbral. Es un buen adelanto de la clase de AO real.

## Notas
- **P3 corre en cámara lenta**: 1 s de reloj equivale a 2 ms simulados (500 veces más lento). Así se alcanzan a ver las ondas de 1 kHz en los osciloscopios.
- P1, P2 y P4 corren en tiempo real.
- En **MATLAB Online** los osciloscopios del tablero pueden mostrar "Unconnected" encima de las curvas. Las señales sí llegan; si una curva no se ve, haga zoom sobre el bloque.
- En P4, el pulsador del tablero solo descarga el capacitor mientras está oprimido. Suéltelo para que empiece a contar el tiempo.
