%% practica3_generador.m - Electronica Analogica (UNAL) - Clase 10
% PRACTICA 3 - GENERADOR DE FUNCIONES (onda cuadrada + triangular) y PWM
%   AO1: integrador (R = 75k, C = 10 nF)  -> triangular
%   AO2: comparador con histeresis no inversor con Vref = 0 (R = 10k, nR = 30k)
%        -> cuadrada de +-12 V; umbrales +-Vsat/n = +-4 V (amplitud de la triangular)
%   f = n/(4*R*C) = 3/(4*75k*10n) = 1 kHz
%   AO3: comparador simple: Vc contra la triangular -> PWM; ciclo util D = (Vc+4)/8
%   Un filtro RC (10k, 2 uF) saca el voltaje promedio del PWM (lo que "siente" un motor).
%   La simulacion corre en CAMARA LENTA (500 veces mas lenta) para poder verla.
U = ea_lib();
mdl = 'generador_funciones_pwm';
if bdIsLoaded(mdl), close_system(mdl,0); end
new_system(mdl);

%% Parametros
P = struct('Vsat',12,'Aol',1e5,'Rint',75e3,'Cint',10e-9,'Rs',10e3,'nRs',30e3, ...
           'Vc',2,'Rf',10e3,'Cf',2e-6);
ws = get_param(mdl,'ModelWorkspace');
for f = fieldnames(P)', assignin(ws,f{1},P.(f{1})); end

%% 1 - Integrador (AO1)
U.aoBL(mdl,'AO1',[420 300],'0');
U.placeAt(mdl,'AO1','LConn',2,[380 285]);
U.Rb(mdl,'R integrador',[300 285],'Rint',false,true);
U.placeAt(mdl,'R integrador','RConn',1,[340 285]);
U.W(mdl,{'R integrador','RConn',1},{'AO1','LConn',2});
U.Cb(mdl,'C integrador',[440 200],'Cint','0',false);
U.W(mdl,{'AO1','LConn',2},{'C integrador','LConn',1});
U.W(mdl,{'C integrador','RConn',1},{'AO1','RConn',1});
U.gnd(mdl,'GND AO1',[370 350]);
U.W(mdl,{'AO1','LConn',1},{'GND AO1','LConn',1});
U.addb(mdl,'Solver Configuration','Solver',[280 400],[40 30]);
U.W(mdl,{'Solver','RConn',1},{'GND AO1','LConn',1});


%% 2 - Comparador con histeresis no inversor, Vref = 0 (AO2)
U.aoBL(mdl,'AO2',[760 300],'Vsat');
U.placeAt(mdl,'AO2','LConn',1,[720 315]);
U.Rb(mdl,'R Schmitt',[640 315],'Rs');
U.W(mdl,{'AO1','RConn',1},{'R Schmitt','LConn',1});
U.W(mdl,{'R Schmitt','RConn',1},{'AO2','LConn',1});
U.Rb(mdl,'nR Schmitt',[770 420],'nRs',false,true);
U.W(mdl,{'R Schmitt','RConn',1},{'nR Schmitt','LConn',1});
U.W(mdl,{'nR Schmitt','RConn',1},{'AO2','RConn',1});
U.gnd(mdl,'GND AO2',[700 250]);
U.W(mdl,{'AO2','LConn',2},{'GND AO2','LConn',1});
% la cuadrada vuelve a la entrada del integrador
U.W(mdl,{'AO2','RConn',1},{'R integrador','LConn',1});


%% 3 - PWM (AO3): Vc a la (+), triangular a la (-), y promedio con RC
U.addb(mdl,'simulink/Sources/Constant','Vc (V)',[560 560],[50 30]);
U.sp(mdl,'Vc (V)','Value','Vc','SampleTime','1e-4');
U.psrc(mdl,'Fuente Vc',[700 600],'Vc (V)','1e-4');
U.aoBL(mdl,'AO3',[900 560],'0');
U.W(mdl,{'Fuente Vc','LConn',1},{'AO3','LConn',1});
U.W(mdl,{'AO1','RConn',1},{'AO3','LConn',2});
U.Rb(mdl,'R filtro',[1020 560],'Rf');
U.W(mdl,{'AO3','RConn',1},{'R filtro','LConn',1});
U.Cb(mdl,'C filtro',[1090 620],'Cf','0',true);
U.placeTop(mdl,'C filtro',U.pt(mdl,'R filtro','RConn',1)+[30 30]);
U.gnd(mdl,'GND filtro',U.pt(mdl,'C filtro',U.botName(mdl,'C filtro'),1)+[0 20]);
U.W(mdl,{'R filtro','RConn',1},{'C filtro',U.topName(mdl,'C filtro'),1});
U.W(mdl,{'C filtro',U.botName(mdl,'C filtro'),1},{'GND filtro','LConn',1});


%% 4 - Voltimetros
U.vmeter(mdl,'Triangular',{'AO1','RConn',1},'tri',[230 110]);
U.vmeter(mdl,'Cuadrada',{'AO2','RConn',1},'sq',[880 150]);
U.vmeter(mdl,'PWM',{'AO3','RConn',1},'pwm',[960 700]);
U.vmeter(mdl,'Promedio',{'C filtro',U.topName(mdl,'C filtro'),1},'avg',[1180 560]);
U.fro(mdl,'From avg','avg',[1470 560]);
U.addb(mdl,'simulink/Math Operations/Bias','+12',[1540 560],[40 30]); U.sp(mdl,'+12','Bias','Vsat');
U.addb(mdl,'simulink/Math Operations/Gain','Ciclo util (%)',[1610 560],[50 30]); U.sp(mdl,'Ciclo util (%)','Gain','100/(2*Vsat)');
U.addb(mdl,'simulink/Sinks/Terminator','Term D',[1680 560],[16 16]);
add_line(mdl,'From avg/1','+12/1'); add_line(mdl,'+12/1','Ciclo util (%)/1'); add_line(mdl,'Ciclo util (%)/1','Term D/1');
U.area(mdl,'1 . Integrador (AO1): triangular',{'AO1','R integrador','C integrador','GND AO1','Solver','Triangular','GND Triangular','Triangular (V)','Goto tri'});
U.area(mdl,'2 . Comparador con histeresis no inversor (AO2): cuadrada',{'AO2','R Schmitt','nR Schmitt','GND AO2','Cuadrada','GND Cuadrada','Cuadrada (V)','Goto sq'});
U.area(mdl,'3 . PWM (AO3) y voltaje promedio (filtro RC)',{'Vc (V)','S-PS Fuente Vc','Fuente Vc','GND Fuente Vc', ...
   'AO3','R filtro','C filtro','GND filtro','PWM','GND PWM','PWM (V)','Goto pwm','Promedio','GND Promedio','Promedio (V)','Goto avg'});
U.area(mdl,'4 . Ciclo util medido a partir del voltaje promedio',{'From avg','+12','Ciclo util (%)','Term D'});

%% 5 - Tablero en vivo
y0 = 820; H = U;
k1 = H.hmi(mdl,'Knob','Perilla: R del integrador (ohm) - frecuencia',[60 y0 260 y0+190]);
set_param(k1,'Limits',[20e3 200e3]); H.bindParam(k1,[mdl '/R integrador'],'R');
k2 = H.hmi(mdl,'Knob','Perilla: nR del Schmitt (ohm) - amplitud',[290 y0 490 y0+190]);
set_param(k2,'Limits',[15e3 60e3]); H.bindParam(k2,[mdl '/nR Schmitt'],'R');
s1 = H.hmi(mdl,'Slider','Voltaje de control Vc (V)',[520 y0+50 800 y0+130]);
set_param(s1,'Limits',[-4 4]); H.bindParam(s1,[mdl '/Vc (V)'],'Value');
g1 = H.hmi(mdl,'Half Gauge','Voltaje promedio del PWM (V)',[830 y0+20 1050 y0+140]);
set_param(g1,'Limits',[-12 12]); H.bindSig(g1,[mdl '/Promedio (V)']);
d1 = H.hmi(mdl,'Display','Medidor: ciclo util (%)',[1080 y0+50 1260 y0+110]);
H.bindSig(d1,[mdl '/Ciclo util (%)']);
U.areaBox(mdl,'5 . Tablero en vivo - camara lenta: 1 ms de simulacion = 0.5 s de reloj',[30 y0-45 1300 y0+230]);

%% 6 - Osciloscopios en el lienzo
y1 = y0 + 300;
U.probe(mdl,'s_tri','tri','1',[60 y1+290],'Triangular (V)','2e-5');
U.probe(mdl,'s_sq','sq','1',[60 y1+330],'Cuadrada (V)','2e-5');
U.probe(mdl,'s_pwm','pwm','1',[60 y1+370],'PWM (V)','2e-5');
U.probe(mdl,'s_vc','Vc_sig','1',[60 y1+410],'Vc (V)','2e-5');
U.gto(mdl,'Goto Vc','Vc_sig',[620 600]);
add_line(mdl,'Vc (V)/1','Goto Vc/1','autorouting','smart');
U.dscope(mdl,'Cuadrada (AO2) y triangular (AO1) (V)',[60 y1 640 y1+240],{'s_sq','s_tri'},5e-3,[-14 14]);
U.dscope(mdl,'PWM (AO3), triangular y Vc (V)',[680 y1 1260 y1+240],{'s_pwm','s_tri','s_vc'},5e-3,[-14 14]);
U.areaBox(mdl,'6 . Osciloscopios en vivo (ventana de 5 ms = 5 periodos)',[30 y1-45 1300 y1+450]);

%% Simulacion en camara lenta (PacingRate = 0.002: 1 s de reloj = 2 ms simulados)
set_param(mdl,'StopTime','inf','Solver','ode23t','MaxStep','1e-5','EnablePacing','on','PacingRate',0.002, ...
    'SignalLogging','on','ReturnWorkspaceOutputs','on');
U.check(mdl);
carpeta = fileparts(mfilename('fullpath'));
save_system(mdl,fullfile(carpeta,[mdl '.slx']));
fprintf('Practica 3 lista: abre %s.slx y dale Run.\n',mdl);
